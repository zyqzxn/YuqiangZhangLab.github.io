#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                 Main script for validation                              ++
#                         Lei Zhu (leizhu@fas.harvard.edu), 07/20/2020                    ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////


#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                      STEP 1                                             ++
#                              Load library and tools                                     ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

#---> Load libraies
library(fields); library(rhdf5); library(SDMTools); library(RNetCDF); library(lubridate)
library(akima)

#---> Set working dir
setwd("/data/working/validation/")

#---> Load my tools
source("tools.R")

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                      STEP 2                                             ++
#                      Set working dir, data dir, and parameters                          ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

#---> RData folder
RData_folder        <- "RData/"

#---> Set GEOS-Chem output path
# ts hourly file path
GC_ts_folder        <- "/data/LAND/GC/GEOSFP_0.25_NA/ts/nc/"
# plane log file
planelog_dir        <- "/data/LAND/GC/GEOSFP_0.25_NA/plane/"
# Get the plane log file list
planelog_list       <- list.files(planelog_dir)
# plane log file, prefix
planelog_pre        <- "plane.log."
# plane log file, suffix
planelog_sub        <- ""

#---> Set OMI L2 file path
L2_data_folder      <- "/data/OMI_v3.0/L2_hdf/"

#---> Get Campaign information
Campaign_info       <- read.table("Campaigns.dat", header=T)

#---> Set MAX flight obs points
MAX_points          <- 1e6

#---> Set MAX pixels of each cell
MAX_pixels          <- 5e2

#---> Set spatial resolution
Res                 <- 0.5

#---> Bin data by height
# Max height
MAX_Height          <- 15 # km

# Number of groups
Ngroups 	          <- 30

#---> Set the limits for satellite pixels
VCD_limit           <- c( -0.8e16, 7.6e16 )
CF_limit            <- c(  0.0   , 0.3    ) 
SZA_limit           <- c(  0.0   , 60.0   )

#---> Min pixels needed for a valide average
Pixel_limit         <- 0

#---> Set the level of tropopause
TR                  <- 33

#---> Set the level of GC output
NLEVS_GC            <- 47

#---> Set LT hour range for averaging
LT_hour1            <- 13
LT_hour2            <- 14

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Get Campaign information
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Campaign_ID         <- 1
Campaign_NO         <- as.character(Campaign_info$No[Campaign_ID])
Campaign_name       <- as.character(Campaign_info$Campaign[Campaign_ID])
Campaign_date       <- seq(as.Date(Campaign_info$Date_Start[Campaign_ID]), as.Date(Campaign_info$Date_End[Campaign_ID]), "days")
NDAYS               <- length(Campaign_date)
Plot_Lon_grid       <- seq(Campaign_info$PlotLon1[Campaign_ID]+0.5*Res,Campaign_info$PlotLon2[Campaign_ID]-0.5*Res,by=Res)
Plot_Lat_grid       <- seq(Campaign_info$PlotLat1[Campaign_ID]+0.5*Res,Campaign_info$PlotLat2[Campaign_ID]-0.5*Res,by=Res)
Plot_Domain_Lon     <- c(Campaign_info$PlotLon1[Campaign_ID],Campaign_info$PlotLon2[Campaign_ID],
                         Campaign_info$PlotLon2[Campaign_ID],Campaign_info$PlotLon1[Campaign_ID])
Plot_Domain_Lat     <- c(Campaign_info$PlotLat2[Campaign_ID],Campaign_info$PlotLat2[Campaign_ID],
                         Campaign_info$PlotLat1[Campaign_ID],Campaign_info$PlotLat1[Campaign_ID])
Region_Lon          <- c(Campaign_info$StudyLon1[Campaign_ID],Campaign_info$StudyLon2[Campaign_ID],
                         Campaign_info$StudyLon2[Campaign_ID],Campaign_info$StudyLon1[Campaign_ID])
Region_Lat          <- c(Campaign_info$StudyLat2[Campaign_ID],Campaign_info$StudyLat2[Campaign_ID],
                         Campaign_info$StudyLat1[Campaign_ID],Campaign_info$StudyLat1[Campaign_ID])

#---> Aircraft merge files, make sure format is consistent with a specific campaign
# merge file path
merge_dir           <- "/data/LAND/flight/P3B/"
# merge file
merge_pre           <- "discoveraq-mrg10-p3b_merge_"
# merge file
merge_sub           <- "_R4.ict"


#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                      STEP 3                                             ++
#                          Read merge file and plane log files                            ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

# ------------------------------------------------------------------------------------------
# Read merge file
# ------------------------------------------------------------------------------------------

#---> Define arraies
Obs_Second          <- array(NA,dim=c(MAX_points))   # Time stamp, second since 2010-01-01
Obs_P               <- array(NA,dim=c(MAX_points))   # Obs pressure  , [hPa]
Obs_T               <- array(NA,dim=c(MAX_points))   # Obs temperture, [K]
Obs_H               <- array(NA,dim=c(MAX_points))   # Obs altitudes , [km]
Obs_Lat             <- array(NA,dim=c(MAX_points))   # Obs lat
Obs_Lon             <- array(NA,dim=c(MAX_points))   # Obs lon
Obs_MX	            <- array(NA,dim=c(MAX_points,2)) # Obs mixing ratios, some campaigns have more than 1 HCHO data set
Obs_points          <- 0

#---> Loop days over the whole campaign period
for(iday in 1:NDAYS ){
  
  # Get date
  temp_date         <- paste(substr(Campaign_date[iday],1,4),substr(Campaign_date[iday],6,7),substr(Campaign_date[iday],9,10),sep="")
  
  # Get merge file name
  merge_file    	  <- paste(merge_dir, merge_pre, temp_date, merge_sub, sep="")
  
  # Does this merge file exist?
  if(file.exists(merge_file)){
    # Read  merge file
    print(paste("  - Read flight data at:",temp_date))
    flight_data     <- read_ICT(merge_file)
  }else{
    next
  }

  # Get Time, HCHO, T, P, and height
  UTC_temp          <- flight_data$UTC                       # s
  Lat_temp          <- flight_data$LATITUDE
  Lon_temp          <- flight_data$LONGITUDE-360             # Change Lon format
  HCHO_temp         <- flight_data$CH2O_DFGAS*1e-3           # ppb
  T_temp            <- flight_data$TEMPERATURE               # K
  P_temp            <- flight_data$PRESSURE                  # hPa
  H_temp            <- flight_data$ALTP                      # km
  
  # Discard unvalid data points
  Valid_list1       <- common(common(which(Lat_temp>(-90)),which(Lat_temp<90)), common(which(Lon_temp>(-180)),which(Lon_temp<180)))
  Valid_list2       <- common(common(common(which(HCHO_temp>0),which(T_temp>0)),which(P_temp>0)),which(H_temp>0))          
  Valid_list        <- common(Valid_list1, Valid_list2)
  
  # Save valid data points
  if( length(Valid_list)>0 ){
    List_all                            <- c(Obs_points+1,Obs_points+length(Valid_list))
    
    Obs_Second[List_all[1]:List_all[2]] <- get_seconds_2010(Campaign_date[iday])+UTC_temp[Valid_list] #s
    Obs_P[List_all[1]:List_all[2]]      <- P_temp[Valid_list]                  # hPa
    Obs_Lat[List_all[1]:List_all[2]]    <- Lat_temp[Valid_list]
    Obs_Lon[List_all[1]:List_all[2]]    <- Lon_temp[Valid_list]                # Lon
    Obs_T[List_all[1]:List_all[2]]      <- T_temp[Valid_list]                  # K
    Obs_H[List_all[1]:List_all[2]]      <- H_temp[Valid_list]                  # km
    Obs_MX[List_all[1]:List_all[2],1]   <- HCHO_temp[Valid_list]               # ppb    

    Obs_points <- Obs_points + length(Valid_list)
  }
}

#---> Resize the arraies
Obs_Second          <- Obs_Second[1:Obs_points]
Obs_P               <- Obs_P[1:Obs_points]
Obs_T               <- Obs_T[1:Obs_points]
Obs_H               <- Obs_H[1:Obs_points]
Obs_Lat             <- Obs_Lat[1:Obs_points]
Obs_Lon             <- Obs_Lon[1:Obs_points]
Obs_MX              <- Obs_MX[1:Obs_points,]

# ------------------------------------------------------------------------------------------
# Read GEOS-Chem 1 min-average file, and average obs
# ------------------------------------------------------------------------------------------

#---> Define arraies
# Time stamp
Avg_timestamp       <- array(NA,dim=c(MAX_points))   # HHMM
# GEOS-Chem P, T, Lat, Lon, and mixing ratio
Avg_GC_P            <- array(NA,dim=c(MAX_points))   # Obs pressure  , [hPa]
Avg_GC_T            <- array(NA,dim=c(MAX_points))   # Obs temperture, [K]
Avg_GC_Lat          <- array(NA,dim=c(MAX_points))   # Obs lat
Avg_GC_Lon          <- array(NA,dim=c(MAX_points))   # Obs lon
Avg_GC_MX           <- array(NA,dim=c(MAX_points))   # Mixing ratios,  [ppbv]
# Observed P, T, height, Lat, Lon, and mixing ratio
Avg_Obs_P           <- array(NA,dim=c(MAX_points))   # Obs pressure  , [hPa]
Avg_Obs_T           <- array(NA,dim=c(MAX_points))   # Obs temperture, [K]
Avg_Obs_H           <- array(NA,dim=c(MAX_points))   # Obs altitudes , [km]
Avg_Obs_Lat         <- array(NA,dim=c(MAX_points))   # Obs lat
Avg_Obs_Lon         <- array(NA,dim=c(MAX_points))   # Obs lon
Avg_Obs_MX          <- array(NA,dim=c(MAX_points,2)) # Obs mixing ratios
Avg_points          <- 0

#---> Loop days over the whole campaign period
for(iday in 1:NDAYS ){
  
  # Get date
  temp_date         <- paste(substr(Campaign_date[iday],1,4),substr(Campaign_date[iday],6,7),substr(Campaign_date[iday],9,10),sep="")
  
  # planelog file
  planelog_file    	<- paste(planelog_dir, planelog_pre, temp_date, planelog_sub, sep="")
  
  # Does this merge file exist?
  if(file.exists(planelog_file)){
    # Read  planelog file from GEOS-Chem
    print(paste("  - Read planelog file at:",temp_date))
    GC_data         <- read.table(planelog_file,header=T)
  }else{
    next
  }
  
  # Total number of obs points
  N_points          <- dim(GC_data)[1]
  
  # Loop 1-min data points
  for(ipoint in 1:N_points){
  	
    # Get timestamp
    if(GC_data$HHMM[ipoint]<10){
      c_HHMM        <- paste("000",as.character(GC_data$HHMM[ipoint]),sep="")
    }
    if(GC_data$HHMM[ipoint]>=10 && GC_data$HHMM[ipoint]<100 ){
      c_HHMM        <- paste("00",as.character(GC_data$HHMM[ipoint]),sep="")
    }   
    if(GC_data$HHMM[ipoint]>=100 && GC_data$HHMM[ipoint]<1000 ){
      c_HHMM        <- paste("0",as.character(GC_data$HHMM[ipoint]),sep="")
    }
    if( GC_data$HHMM[ipoint]>=1000 ){
      c_HHMM        <- as.character(GC_data$HHMM[ipoint])
    }
    temp_stamp      <- paste(Campaign_date[iday]," ",substr(c_HHMM,1,2),":",substr(c_HHMM,3,4),sep="")
    temp_second     <- get_seconds_2010(Campaign_date[iday]) + as.integer(substr(c_HHMM,1,2))*3600 + as.integer(substr(c_HHMM,3,4))*60
    
    # Match GC with flight observations
    temp_list       <- common(which(Obs_Second >= temp_second), which(Obs_Second < temp_second+60))
    
    # Average and save observations
    if(length(temp_list) > 0){
      Avg_points                <- Avg_points + 1
      Avg_timestamp[Avg_points] <- temp_stamp
      # GEOS-Chem 1-min average
      Avg_GC_P[Avg_points]      <- GC_data$GMAO_PRES[ipoint]
      Avg_GC_T[Avg_points]      <- GC_data$GMAO_TEMP[ipoint]
      Avg_GC_Lat[Avg_points]    <- GC_data$LAT[ipoint]
      Avg_GC_Lon[Avg_points]    <- GC_data$LON[ipoint]
      Avg_GC_MX[Avg_points]     <- GC_data$TRA_020[ipoint]*1e9 # ppb
      # Flight observations, averaged to 1-min
      Avg_Obs_P[Avg_points]     <- mean(Obs_P[temp_list]   , na.rm=T)
      Avg_Obs_T[Avg_points]     <- mean(Obs_T[temp_list]   , na.rm=T)
      Avg_Obs_H[Avg_points]     <- mean(Obs_H[temp_list]   , na.rm=T)
      Avg_Obs_Lat[Avg_points]   <- mean(Obs_Lat[temp_list] , na.rm=T)
      Avg_Obs_Lon[Avg_points]   <- mean(Obs_Lon[temp_list] , na.rm=T)
      Avg_Obs_MX[Avg_points,1]  <- mean(Obs_MX[temp_list,1], na.rm=T)
      Avg_Obs_MX[Avg_points,2]  <- mean(Obs_MX[temp_list,2], na.rm=T)
    }
  }
}

#---> Resize the arraies
Avg_timestamp       <- Avg_timestamp[1:Avg_points]
Avg_GC_P            <- Avg_GC_P[1:Avg_points]
Avg_GC_T            <- Avg_GC_T[1:Avg_points]
Avg_GC_Lat          <- Avg_GC_Lat[1:Avg_points]
Avg_GC_Lon          <- Avg_GC_Lon[1:Avg_points]
Avg_GC_MX           <- Avg_GC_MX[1:Avg_points]
Avg_Obs_P           <- Avg_Obs_P[1:Avg_points]
Avg_Obs_T           <- Avg_Obs_T[1:Avg_points]
Avg_Obs_H           <- Avg_Obs_H[1:Avg_points]
Avg_Obs_Lat         <- Avg_Obs_Lat[1:Avg_points]
Avg_Obs_Lon         <- Avg_Obs_Lon[1:Avg_points]
Avg_Obs_MX          <- Avg_Obs_MX[1:Avg_points,]

# Get the date with obs
Date_with_obs         <- unique(paste(substr(Avg_timestamp,1,4),substr(Avg_timestamp,6,7),substr(Avg_timestamp,9,10),sep="-"))
Date_with_obs_index   <- c()
for(iday in 1:length(Date_with_obs)){
	Date_with_obs_index <- c(Date_with_obs_index, grep(Date_with_obs[iday], Campaign_date))
}

# ------------------------------------------------------------------------------------------
# Bin data by height
# ------------------------------------------------------------------------------------------

#---> Get the group id, binned by 0.5 km
group 	            <- c()
group_div           <- seq(0,MAX_Height,by=(MAX_Height/Ngroups))

for(i in 1:length(Avg_Obs_H)){
  
  # Make sure only handel obs within the study area
  In_Domain         <- pnt.in.poly(cbind(Avg_Obs_Lon[i],Avg_Obs_Lat[i] ),cbind(Region_Lon, Region_Lat))$pip
  
  if(In_Domain){
    nearest_point   <- which(abs(Avg_Obs_H[i]-group_div)==min(abs(Avg_Obs_H[i]-group_div)))[1]
    if((Avg_Obs_H[i]-group_div[nearest_point])==0){
      group_id 	    <- nearest_point
    }else{
      if(Avg_Obs_H[i]>group_div[nearest_point]){
        group_id    <- nearest_point
      }else{
        group_id    <- nearest_point - 1
      }
    }	
  }else{
    group_id        <- -9999
  }
  group             <- c(group, group_id)
}

#---> Get mean profiles
Profile_GC_mean           <- array(NA,dim=c(Ngroups))
Profile_GC_median         <- array(NA,dim=c(Ngroups))
Profile_GC_sd             <- array(NA,dim=c(Ngroups))
Profile_GC_N              <- array(NA,dim=c(Ngroups))
Profile_GC_mean_T         <- array(NA,dim=c(Ngroups))
Profile_GC_mean_P         <- array(NA,dim=c(Ngroups))

Profile_Obs_mean          <- array(NA,dim=c(Ngroups,2))
Profile_Obs_median        <- array(NA,dim=c(Ngroups,2))
Profile_Obs_sd            <- array(NA,dim=c(Ngroups,2))
Profile_Obs_N             <- array(NA,dim=c(Ngroups,2))
Profile_Obs_mean_T        <- array(NA,dim=c(Ngroups))
Profile_Obs_mean_P        <- array(NA,dim=c(Ngroups))

for(i in 1:Ngroups){
  index                   <- which(group==i)	
  Profile_GC_mean[i] 	    <- mean(Avg_GC_MX[index], na.rm=T)
  Profile_GC_median[i] 	  <- median(Avg_GC_MX[index], na.rm=T)    
  Profile_GC_sd[i] 	      <- sd(Avg_GC_MX[index], na.rm=T)
  Profile_GC_N[i] 		    <- sum(!is.na(Avg_GC_MX[index]))
  Profile_GC_mean_T[i] 	  <- mean(Avg_GC_T[index], na.rm=T)
  Profile_GC_mean_P[i] 	  <- mean(Avg_GC_P[index], na.rm=T)
  
  Profile_Obs_mean[i,1]   <- mean(Avg_Obs_MX[index,1],na.rm=T)
  Profile_Obs_median[i,1] <- median(Avg_Obs_MX[index,1],na.rm=T)    
  Profile_Obs_sd[i,1] 	  <- sd(Avg_Obs_MX[index,1],na.rm=T)
  Profile_Obs_N[i,1] 	    <- sum(!is.na(Avg_Obs_MX[index,1]))
  Profile_Obs_mean_T[i]   <- mean(Avg_Obs_T[index], na.rm=T)
  Profile_Obs_mean_P[i]   <- mean(Avg_Obs_P[index], na.rm=T)  
  
  Profile_Obs_mean[i,2]   <- mean(Avg_Obs_MX[index,2],na.rm=T)
  Profile_Obs_median[i,2] <- median(Avg_Obs_MX[index,2],na.rm=T)    
  Profile_Obs_sd[i,2] 	  <- sd(Avg_Obs_MX[index,2],na.rm=T)
  Profile_Obs_N[i,2] 	    <- sum(!is.na(Avg_Obs_MX[index,2]))
}

# ------------------------------------------------------------------------------------------
# Save RData
# ------------------------------------------------------------------------------------------
RData_name	              <- paste(RData_folder,Campaign_NO,"_",Campaign_name,"_profile.RData",sep="")

save(file=RData_name, Avg_Obs_MX         , Avg_GC_MX          , Avg_Obs_P         , Avg_GC_P            , 
                      Avg_GC_Lat         , Avg_Obs_Lat        , Avg_Obs_Lon       , Avg_GC_Lon          , 
                      Avg_Obs_T          , Avg_GC_T           , Profile_GC_mean   , Profile_Obs_mean    , 
                      Profile_Obs_sd     , Profile_GC_mean_P  , Profile_GC_mean_T , Profile_GC_mean     , 
                      Profile_Obs_mean_P , Profile_Obs_mean_T , Profile_Obs_mean  , MAX_Height          , 
                      Ngroups            , Obs_Lon            , Obs_Lat           , Obs_H               , 
                      Obs_MX             , Obs_points         , Date_with_obs     , Date_with_obs_index )


#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                      STEP 4                                             ++
#                                Read GC ts hourly files                                  ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

RData_name	            <- paste(RData_folder,Campaign_NO,"_",Campaign_name,"_profile.RData",sep="")
load(RData_name)

#---> Get grids
date_temp0              <- paste(substr(Date_with_obs[1],1,4),substr(Date_with_obs[1],6,7),substr(Date_with_obs[1],9,10),sep="")
ts_file       	        <- paste(GC_ts_folder,"ts.", date_temp0,".010000.nc",sep="")
if(file.exists(ts_file)){
  ex.nc	                <- open.nc(ts_file)
  GC_Lat_all            <- var.get.nc(ex.nc,"LAT")
  GC_Lon_all            <- var.get.nc(ex.nc,"LON")
  close.nc(ex.nc)
}else{
  print(paste(ts_file,"NOT found!!!"))
}

#---> Get the region of plot
# Make the plot region slighly larger
Col_left_GC             <- which.min(abs(min(Plot_Lon_grid)-GC_Lon_all))[1]-2
Col_right_GC            <- which.min(abs(max(Plot_Lon_grid)-GC_Lon_all))[1]+2
Row_low_GC              <- which.min(abs(min(Plot_Lat_grid)-GC_Lat_all))[1]-2
Row_up_GC               <- which.min(abs(max(Plot_Lat_grid)-GC_Lat_all))[1]+2
NROWS_GC                <- Row_up_GC-Row_low_GC+1
NCOLS_GC                <- Col_right_GC-Col_left_GC+1
Lat_grid_GC             <- GC_Lat_all[Row_low_GC:Row_up_GC]
Lon_grid_GC             <- GC_Lon_all[Col_left_GC:Col_right_GC]

#---> Define arries
GC_VCD_hourly           <- array(NA,dim=c(NCOLS_GC, NROWS_GC, NDAYS, 24 ))
GC_T_hourly             <- array(NA,dim=c(NCOLS_GC, NROWS_GC, NDAYS, 24 ))
GC_VCD_UTC_LT_day_index <- array(NA,dim=c(NCOLS_GC, NROWS_GC, NDAYS, 24 ))
GC_VCD_UTC_LT_hour      <- array(NA,dim=c(NCOLS_GC, NROWS_GC, NDAYS, 24 ))
GC_P_hourly             <- array(NA,dim=c(NCOLS_GC, NROWS_GC, NLEVS_GC, NDAYS, 24)) # hPa
GC_AD_hourly            <- array(NA,dim=c(NCOLS_GC, NROWS_GC, NLEVS_GC, NDAYS, 24 )) # molec. cm-3
GC_BXH_hourly           <- array(NA,dim=c(NCOLS_GC, NROWS_GC, NLEVS_GC, NDAYS, 24 )) # m
GC_HCHO_hourly          <- array(NA,dim=c(NCOLS_GC, NROWS_GC, NLEVS_GC, NDAYS, 24 )) # ppb

# ------------------------------------------------------------------------------------------
# Read GC ts hourly file
# ------------------------------------------------------------------------------------------

for(iday in 1:NDAYS ){
  date_temp            <- paste(substr(Campaign_date[iday],1,4),substr(Campaign_date[iday],6,7),substr(Campaign_date[iday],9,10),sep="")
  print(paste("   - Read ts file for:", date_temp))
  
  # Loop hourly file
  for(ihour in 1:24){
    if(ihour!=24){
      ts_file          <- paste(GC_ts_folder, "ts.", date_temp,".", Integer2character(ihour),"0000.nc",sep="")
    }else{
      date_next        <- get_next_day(Campaign_date[iday]) 
      date_temp        <- paste(substr(date_next,1,4),substr(date_next,6,7),substr(date_next,9,10),sep="") 	
      ts_file          <- paste(GC_ts_folder, "ts.", date_temp,".","000000.nc",sep="")
    }
    
    # Now read ts file
    if(file.exists(ts_file)){
      ex.nc	           <- open.nc(ts_file)
      HCHO_MX          <- var.get.nc(ex.nc,"IJ-AVG-S__CH2O")[Col_left_GC:Col_right_GC,Row_low_GC:Row_up_GC,]      # ppbv
      Air_ND           <- var.get.nc(ex.nc,"TIME-SER__AIRDEN")[Col_left_GC:Col_right_GC,Row_low_GC:Row_up_GC,]    # molec cm-3
      BXH              <- var.get.nc(ex.nc,"BXHGHT-S__BXHEIGHT")[Col_left_GC:Col_right_GC,Row_low_GC:Row_up_GC,]  # m
      Press            <- var.get.nc(ex.nc,"PEDGE-S__PSURF")[Col_left_GC:Col_right_GC,Row_low_GC:Row_up_GC,]      # hPa
      Temperature      <- var.get.nc(ex.nc,"DAO-3D-S__TMPU")[Col_left_GC:Col_right_GC,Row_low_GC:Row_up_GC,1]     # K     
      close.nc(ex.nc)
    }else{
      print(paste("  -", ts_file, " NOT found!!!"))
    }
    
    # Compute column and save T
    HCHO_column        <- array(NA, dim=c( NCOLS_GC, NROWS_GC ))   
    
    for(icol in 1:NCOLS_GC ){
      
      # Get local time
      LT_hour      <- ihour-0.5 + GC_Lon_all[Col_left_GC + icol - 1]/15.0
      Day_change   <- 0
      if(LT_hour > 24){
        LT_hour    <- LT_hour - 24
        Day_change <- 1
      }
      if(LT_hour < 0){
        LT_hour    <- LT_hour + 24
        Day_change <- -1
      }
      # Save LT date and hour
      if((iday + Day_change)>0){ # Skip the very first day
        GC_VCD_UTC_LT_day_index[icol, ,iday, ihour]  <- iday + Day_change
      }
      GC_VCD_UTC_LT_hour[icol, ,iday, ihour]         <- LT_hour 		
      # Compute column
      for(irow in 1:NROWS_GC ){
        HCHO_column[icol,irow]     <- sum(HCHO_MX[icol,irow,1:TR]*1e-9*Air_ND[icol,irow,1:TR]*BXH[icol,irow,1:TR]*1e2, na.rm=T)
      }
    }
    
    # Save data
    GC_HCHO_hourly[ , , , iday, ihour] <- HCHO_MX
    GC_P_hourly[ , , , iday, ihour]    <- Press
    GC_AD_hourly[ , , , iday, ihour]   <- Air_ND
    GC_BXH_hourly[ , , , iday, ihour]  <- BXH
    GC_VCD_hourly[ , ,iday, ihour]     <- HCHO_column
    GC_T_hourly[ , ,iday, ihour]       <- Temperature
  }
}

# ------------------------------------------------------------------------------------------
# Get column at LT 13-14 
# ------------------------------------------------------------------------------------------

GC_1314LT_CT          <- array(0,dim=c(NCOLS_GC, NROWS_GC, NDAYS ))
GC_VCD_1314LT_sum     <- array(0,dim=c(NCOLS_GC, NROWS_GC, NDAYS ))
GC_T_1314LT_sum       <- array(0,dim=c(NCOLS_GC, NROWS_GC, NDAYS ))
GC_HCHO_1314LT_sum    <- array(0,dim=c(NCOLS_GC, NROWS_GC, NLEVS_GC, NDAYS ))
GC_P_1314LT_sum       <- array(0,dim=c(NCOLS_GC, NROWS_GC, NLEVS_GC, NDAYS ))
GC_BXH_1314LT_sum     <- array(0,dim=c(NCOLS_GC, NROWS_GC, NLEVS_GC, NDAYS ))
GC_AD_1314LT_sum      <- array(0,dim=c(NCOLS_GC, NROWS_GC, NLEVS_GC, NDAYS ))

for(iday in 1:NDAYS ){
  for(ihour in 1:24){
    for(col in 1: NCOLS_GC){
      for(row in 1: NROWS_GC){
        if( (GC_VCD_UTC_LT_hour[col,row,iday,ihour] >= LT_hour1) && (GC_VCD_UTC_LT_hour[col,row,iday,ihour] <= LT_hour2) &&
            !is.na(GC_VCD_UTC_LT_day_index[col,row,iday,ihour]) ) {
          day_use                            <- GC_VCD_UTC_LT_day_index[col,row,iday,ihour]
          GC_1314LT_CT[col,row,day_use]      <- GC_1314LT_CT[col,row,day_use] + 1
          GC_VCD_1314LT_sum[col,row,day_use] <- GC_VCD_1314LT_sum[col,row,day_use] + GC_VCD_hourly[col,row,iday,ihour]  	
          GC_T_1314LT_sum[col,row,day_use]   <- GC_T_1314LT_sum[col,row,day_use]   + GC_T_hourly[col,row,iday,ihour]
          for(ilevel in 1:NLEVS_GC){
            GC_HCHO_1314LT_sum[col,row,ilevel,day_use] <- GC_HCHO_1314LT_sum[col,row,ilevel,day_use] + GC_HCHO_hourly[col,row,ilevel,iday,ihour]  	
            GC_P_1314LT_sum[col,row,ilevel,day_use]    <- GC_P_1314LT_sum[col,row,ilevel,day_use]    + GC_P_hourly[col,row,ilevel,iday,ihour]  	
            GC_BXH_1314LT_sum[col,row,ilevel,day_use]  <- GC_BXH_1314LT_sum[col,row,ilevel,day_use]  + GC_BXH_hourly[col,row,ilevel,iday,ihour]  	
            GC_AD_1314LT_sum[col,row,ilevel,day_use]   <- GC_AD_1314LT_sum[col,row,ilevel,day_use]   + GC_AD_hourly[col,row,ilevel,iday,ihour] 
          }
        }
      }
    }
  }	
}

#---> Get daily average at LT 13-14 
GC_VCD_1314LT_daily_avg       <- array(NA,dim=c( NCOLS_GC, NROWS_GC, NDAYS ))
GC_T_1314LT_daily_avg         <- array(NA,dim=c( NCOLS_GC, NROWS_GC, NDAYS ))

GC_P_1314LT_daily_avg         <- array(NA,dim=c( NCOLS_GC, NROWS_GC, NLEVS_GC, NDAYS ))
GC_AD_1314LT_daily_avg        <- array(NA,dim=c( NCOLS_GC, NROWS_GC, NLEVS_GC, NDAYS ))
GC_BXH_1314LT_daily_avg       <- array(NA,dim=c( NCOLS_GC, NROWS_GC, NLEVS_GC, NDAYS ))
GC_HCHO_1314LT_daily_avg      <- array(NA,dim=c( NCOLS_GC, NROWS_GC, NLEVS_GC, NDAYS ))

for(iday in 1:NDAYS ){
  for(col in 1:NCOLS_GC ){
    for(row in 1:NROWS_GC ){
      N_temp <- GC_1314LT_CT[col,row,iday]
      if( N_temp > 0 ){
        GC_VCD_1314LT_daily_avg[col,row,iday]           <- GC_VCD_1314LT_sum[col,row,iday]/N_temp
        GC_T_1314LT_daily_avg[col,row,iday]             <- GC_T_1314LT_sum[col,row,iday]/N_temp
        for(ilevel in 1:NLEVS_GC){
          GC_HCHO_1314LT_daily_avg[col,row,ilevel,iday] <- GC_HCHO_1314LT_sum[col,row,ilevel,iday]/N_temp
          GC_P_1314LT_daily_avg[col,row,ilevel,iday]    <- GC_P_1314LT_sum[col,row,ilevel,iday]/N_temp
          GC_BXH_1314LT_daily_avg[col,row,ilevel,iday]  <- GC_BXH_1314LT_sum[col,row,ilevel,iday]/N_temp
          GC_AD_1314LT_daily_avg[col,row,ilevel,iday]   <- GC_AD_1314LT_sum[col,row,ilevel,iday]/N_temp
        }
      }
    }	
  }
}

#---> Get mean values averaged over dates with obs
GC_VCD_1314LT_Campaign_avg              <- array(NA,dim=c(NCOLS_GC, NROWS_GC))

for(col in 1:NCOLS_GC ){
  for(row in 1:NROWS_GC ){
    GC_VCD_1314LT_Campaign_avg[col,row] <- mean(GC_VCD_1314LT_daily_avg[col,row,Date_with_obs_index], na.rm=T)
  }	
}

# ------------------------------------------------------------------------------------------
# Regrid from GC grids to OMI_grid
# ------------------------------------------------------------------------------------------

Input_Lat             <- c()
Input_Lon             <- c()
Input_GC_column       <- c()

for(row in 1:NROWS_GC ){
  for(col in 1:NCOLS_GC ){
    Input_Lat         <- c(Input_Lat, Lat_grid_GC[row])
    Input_Lon         <- c(Input_Lon, Lon_grid_GC[col])		
    Input_GC_column   <- c(Input_GC_column, GC_VCD_1314LT_Campaign_avg[col,row] )		
  }	
}

Input_HCHO            <- data.frame(Input_GC_column, Input_Lon, Input_Lat)

GC_HCHO_OMI_grids     <- interp(Input_HCHO$Input_Lon, Input_HCHO$Input_Lat, Input_HCHO$Input_GC_column, 
                                xo=Plot_Lon_grid, yo=Plot_Lat_grid, linear=T, extrap=F)

# ------------------------------------------------------------------------------------------
# Save RData
# ------------------------------------------------------------------------------------------
RData_name2	          <- paste(RData_folder,Campaign_NO,"_",Campaign_name,"_GC_column.RData",sep="")

save(file=RData_name2, GC_VCD_1314LT_daily_avg  , GC_T_1314LT_daily_avg    , GC_VCD_1314LT_Campaign_avg , 
                       GC_P_1314LT_daily_avg    , GC_AD_1314LT_daily_avg   , GC_BXH_1314LT_daily_avg    , 
                       GC_HCHO_1314LT_daily_avg , Lat_grid_GC, Lon_grid_GC , GC_HCHO_OMI_grids )

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                      STEP 5                                             ++
#                                Read OMI L2 files                                        ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

RData_name	   <- paste(RData_folder,Campaign_NO,"_",Campaign_name,"_profile.RData",sep="")
load(RData_name)
RData_name2	   <- paste(RData_folder,Campaign_NO,"_",Campaign_name,"_GC_column.RData",sep="")
load(RData_name2)

#---> Get list of L2 files
L2_file_list   <- list.files(L2_data_folder)
L2_file_used   <- c()

#---> Define Group name
GeoField       <- "/HDFEOS/SWATHS/OMI Total Column Amount HCHO/Geolocation Fields/"
DatField       <- "/HDFEOS/SWATHS/OMI Total Column Amount HCHO/Data Fields/"

#---> Define data arraies
Pixel_count    <- 0
OMI_Date       <- array(NA,dim=c(MAX_points))
OMI_Lat        <- array(NA,dim=c(MAX_points))
OMI_Lon        <- array(NA,dim=c(MAX_points))
OMI_VCD        <- array(NA,dim=c(MAX_points))
OMI_SCD        <- array(NA,dim=c(MAX_points))
OMI_Corr       <- array(NA,dim=c(MAX_points))
OMI_VCD_new    <- array(NA,dim=c(MAX_points))
OMI_AMF        <- array(NA,dim=c(MAX_points))
GC_AMF         <- array(NA,dim=c(MAX_points))
OMI_AMF2       <- array(NA,dim=c(MAX_points))
OMI_AMFg       <- array(NA,dim=c(MAX_points))
OMI_Albedo     <- array(NA,dim=c(MAX_points))
OMI_GasProfile <- array(NA,dim=c(MAX_points,NLEVS_GC))
OMI_ScatterW   <- array(NA,dim=c(MAX_points,NLEVS_GC))
OMI_PreLevel   <- array(NA,dim=c(MAX_points,NLEVS_GC))


#---> Read L2 files
for(ifile in 1:length(L2_file_list)){
  
  date_L2      <- paste( substr(L2_file_list[ifile],20,23), substr(L2_file_list[ifile],25,26), substr(L2_file_list[ifile],27,28), sep="-")
  # Get day index
  DAY_temp     <- grep(date_L2, Campaign_date)
  
  # Is this date within the campaign period
  if( length(DAY_temp) > 0 ){
    
    L2_filename    <- L2_file_list[ifile]
    print(paste("  - Process:", L2_filename))
    
    # Open hdf file
    file_name      <- paste(L2_data_folder,L2_filename,sep="")
    Time           <- h5read(file_name,paste(GeoField,"TimeUTC"                               ,sep=""))
    Lat            <- h5read(file_name,paste(GeoField,"Latitude"                              ,sep=""))
    Lon            <- h5read(file_name,paste(GeoField,"Longitude"                             ,sep=""))
    SZA            <- h5read(file_name,paste(GeoField,"SolarZenithAngle"                      ,sep=""))
    VZA            <- h5read(file_name,paste(GeoField,"ViewingZenithAngle"                    ,sep=""))
    CloudFra       <- h5read(file_name,paste(DatField,"AMFCloudFraction"                      ,sep=""))
    MainFlag       <- h5read(file_name,paste(DatField,"MainDataQualityFlag"                   ,sep=""))
    GasProfile     <- h5read(file_name,paste(DatField,"GasProfile"                            ,sep="")) # molec. cm-2
    ScatterW       <- h5read(file_name,paste(DatField,"ScatteringWeights"                     ,sep="")) #
    PreLevel       <- h5read(file_name,paste(DatField,"ClimatologyLevels"                     ,sep="")) # hPa
    VCD            <- h5read(file_name,paste(DatField,"ReferenceSectorCorrectedVerticalColumn",sep="")) #
    SCD            <- h5read(file_name,paste(DatField,"ColumnAmount",sep=""))                           #
    AMF            <- h5read(file_name,paste(DatField,"AirMassFactor"                         ,sep="")) #
    AMFg           <- h5read(file_name,paste(DatField,"AirMassFactorGeometric"                ,sep="")) #
    Albedo         <- h5read(file_name,paste(DatField,"Albedo"                                ,sep="")) #
    
    # Select the data
    NRows          <- dim(VCD)[1]
    NTracks        <- dim(VCD)[2]
    L2_file_used_1st <- 0
    
    # Any pixels in the domain?
    for(irow in 1:NRows){
      In_Domain    <- c()
      In_Domain    <- pnt.in.poly(cbind(Lon[irow,],Lat[irow,]),cbind(Plot_Domain_Lon, Plot_Domain_Lat))$pip
      if(sum(In_Domain)>0){
        L2_file_used_1st <- L2_file_used_1st + 1
        # Now need to save this file
        if(L2_file_used_1st==1){
          L2_file_used <- c(L2_file_used, L2_filename)
        }
        track_list <- which(In_Domain>0)
        for(itrack in 1:length(track_list)){
          if( MainFlag[irow, track_list[itrack]]  == 0            && 
              VCD[irow, track_list[itrack]]       >= VCD_limit[1] && 
              VCD[irow, track_list[itrack]]       <= VCD_limit[2] &&
              CloudFra[irow, track_list[itrack]]  >= CF_limit[1]  && 
              CloudFra[irow, track_list[itrack]]  <= CF_limit[2]  && 
              SZA[irow, track_list[itrack]]       >= SZA_limit[1] && 
              SZA[irow, track_list[itrack]]       <= SZA_limit[2] ){
            
            # Now get a valid pixel
            Pixel_count                  <- Pixel_count + 1
            OMI_Date[Pixel_count]        <- paste(Integer2character(Time[,track_list[itrack]][1]), Integer2character(Time[,track_list[itrack]][2]),
                                                  Integer2character(Time[,track_list[itrack]][3]),sep="")                    
            OMI_Lat[Pixel_count]         <- Lat[irow,track_list[itrack]]
            OMI_Lon[Pixel_count]         <- Lon[irow,track_list[itrack]]                            
            OMI_VCD[Pixel_count]         <- VCD[irow, track_list[itrack]]
            OMI_AMF[Pixel_count]         <- AMF[irow, track_list[itrack]]
            OMI_SCD[Pixel_count]         <- SCD[irow, track_list[itrack]]*AMF[irow, track_list[itrack]]
            OMI_Corr[Pixel_count]        <- SCD[irow, track_list[itrack]]*AMF[irow, track_list[itrack]] - 
                                            VCD[irow, track_list[itrack]]*AMF[irow, track_list[itrack]]
            OMI_AMFg[Pixel_count]        <- AMFg[irow, track_list[itrack]]
            OMI_Albedo[Pixel_count]      <- Albedo[irow, track_list[itrack]]
            OMI_GasProfile[Pixel_count,] <- GasProfile[irow, track_list[itrack],]
            OMI_ScatterW[Pixel_count,]   <- ScatterW[irow, track_list[itrack],]/AMFg[irow, track_list[itrack]] # Need to consider AMFg
            OMI_PreLevel[Pixel_count,]   <- PreLevel[irow, track_list[itrack],]    
            
            # Re-compute the AMF using GC profile
            COL_GC_temp                  <- which.min(abs(OMI_Lon[Pixel_count]-Lon_grid_GC))[1]
            ROW_GC_temp                  <- which.min(abs(OMI_Lat[Pixel_count]-Lat_grid_GC))[1]
            P_GC_pix                     <- GC_P_1314LT_daily_avg[COL_GC_temp,ROW_GC_temp,,DAY_temp]
            HCHO_GC_pix                  <- GC_HCHO_1314LT_daily_avg[COL_GC_temp,ROW_GC_temp,,DAY_temp] # mixing ratio
            AD_GC_pix                    <- GC_AD_1314LT_daily_avg[COL_GC_temp,ROW_GC_temp,,DAY_temp]
            BXH_GC_pix                   <- GC_BXH_1314LT_daily_avg[COL_GC_temp,ROW_GC_temp,,DAY_temp]
            P_OMI_pix                    <- OMI_PreLevel[Pixel_count,]  
            Shape_OMI_pix                <- OMI_GasProfile[Pixel_count,]
            ScaW_OMI_pix                 <- OMI_ScatterW[Pixel_count,]
            AMFg_OMI_pix                 <- OMI_AMFg[Pixel_count]
            
            # Check valid GC output
            if(max(P_GC_pix)==0){
              AMF_temp                   <- c(NA, NA)
            }else{
              AMF_temp                   <- Cal_GC_AMF( P_GC_pix , HCHO_GC_pix  , AD_GC_pix   , BXH_GC_pix, 
                                                        P_OMI_pix, Shape_OMI_pix, ScaW_OMI_pix, AMFg_OMI_pix )  
            }
            
            GC_AMF[Pixel_count]          <- AMF_temp[1]
            # Compute AMF2 here to test 
            OMI_AMF2[Pixel_count]        <- AMF_temp[2]
            
            # Get updated VCD
            OMI_VCD_new[Pixel_count]     <- (OMI_SCD[Pixel_count]-OMI_Corr[Pixel_count])/GC_AMF[Pixel_count] 
          }	
        }	
      }
    } # Loop row (1-60)
  }
}

#---> Resize the arraies
OMI_Date            <- OMI_Date[1:Pixel_count]
OMI_Lat             <- OMI_Lat[1:Pixel_count]
OMI_Lon             <- OMI_Lon[1:Pixel_count]
OMI_VCD             <- OMI_VCD[1:Pixel_count]
OMI_SCD             <- OMI_SCD[1:Pixel_count]
OMI_Corr            <- OMI_Corr[1:Pixel_count]
OMI_VCD_new         <- OMI_VCD_new[1:Pixel_count]
OMI_AMF             <- OMI_AMF[1:Pixel_count]
GC_AMF              <- GC_AMF[1:Pixel_count]
OMI_AMF2            <- OMI_AMF2[1:Pixel_count]
OMI_AMFg            <- OMI_AMFg[1:Pixel_count]
OMI_Albedo          <- OMI_Albedo[1:Pixel_count]
OMI_GasProfile      <- OMI_GasProfile[1:Pixel_count,]
OMI_ScatterW        <- OMI_ScatterW[1:Pixel_count,]
OMI_PreLevel        <- OMI_PreLevel[1:Pixel_count,]

# Compare GC and OMI AMF
reg                 <- lm(GC_AMF~OMI_AMF)
summary(reg)

# ------------------------------------------------------------------------------------------
# Now regrid OMI pixels 
# ------------------------------------------------------------------------------------------

# For pixels within the dates with obs
NCOLS_GRID          <- length(Plot_Lon_grid)
NROWS_GRID          <- length(Plot_Lat_grid)
Grid_N              <- array(0 ,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS ))

# Save all pixels
Grid_VCD_all        <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, MAX_pixels))
Grid_SCD_all        <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, MAX_pixels))
Grid_Corr_all       <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, MAX_pixels))
Grid_AMF_all        <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, MAX_pixels))
Grid_AMF_new_all    <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, MAX_pixels))
Grid_AMFg_all       <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, MAX_pixels))
Grid_Albedo_all     <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, MAX_pixels))
Grid_VCD_new_all    <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, MAX_pixels))
Grid_GasProfile_all <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, MAX_pixels, NLEVS_GC))
Grid_ScatterW_all   <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, MAX_pixels, NLEVS_GC))
Grid_PreLevel_all   <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, MAX_pixels, NLEVS_GC))

# Daily Average
Grid_VCD_d          <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS ))
Grid_SCD_d          <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS))
Grid_Corr_d         <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS))
Grid_AMF_d          <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS))
Grid_AMF_new_d      <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS))
Grid_AMFg_d         <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS))
Grid_Albedo_d       <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS))
Grid_VCD_new_d      <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS ))
Grid_GasProfile_d   <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, NLEVS_GC))
Grid_ScatterW_d     <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, NLEVS_GC))
Grid_PreLevel_d     <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NDAYS, NLEVS_GC))

# Campigan averages
Grid_VCD            <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID))
Grid_SCD            <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID))
Grid_Corr           <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID))
Grid_AMF            <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID))
Grid_AMF_new        <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID))
Grid_AMFg           <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID))
Grid_Albedo         <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID))
Grid_VCD_new        <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID))
Grid_GasProfile     <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NLEVS_GC))
Grid_ScatterW       <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NLEVS_GC))
Grid_PreLevel       <- array(NA,dim=c(NCOLS_GRID, NROWS_GRID, NLEVS_GC))

#---> Loop pixels, store satellite values first
for( ipixel in 1:Pixel_count ){
  Col_index         <- which.min(abs(Plot_Lon_grid-OMI_Lon[ipixel]))[1]
  Row_index         <- which.min(abs(Plot_Lat_grid-OMI_Lat[ipixel]))[1]
  
  # Is this pixel at the date with obs?
  Obs_flag          <- grep(paste(substr(OMI_Date[ipixel],1,4),substr(OMI_Date[ipixel],5,6),substr(OMI_Date[ipixel],7,8),sep="-"), Date_with_obs)
  if(length(Obs_flag)>0){
    Day_index        <- Date_with_obs_index[Obs_flag]
    Pixel_index                                                          <- Grid_N[Col_index, Row_index, Day_index] + 1
    Grid_N[Col_index, Row_index, Day_index]                              <- Pixel_index
    Grid_VCD_all[Col_index, Row_index, Day_index, Pixel_index ]          <- OMI_VCD[ipixel]	
    Grid_SCD_all[Col_index, Row_index, Day_index, Pixel_index ]          <- OMI_SCD[ipixel]
    Grid_Corr_all[Col_index, Row_index, Day_index, Pixel_index ]         <- OMI_Corr[ipixel]
    Grid_AMF_all[Col_index, Row_index, Day_index, Pixel_index ]          <- OMI_AMF[ipixel]	
    Grid_AMF_new_all[Col_index, Row_index, Day_index, Pixel_index ]      <- GC_AMF[ipixel]	
    Grid_AMFg_all[Col_index, Row_index, Day_index, Pixel_index ]         <- OMI_AMFg[ipixel]	
    Grid_Albedo_all[Col_index, Row_index, Day_index, Pixel_index ]       <- OMI_Albedo[ipixel]	
    Grid_VCD_new_all[Col_index, Row_index, Day_index, Pixel_index ]      <- OMI_VCD_new[ipixel]	
    Grid_GasProfile_all[Col_index, Row_index, Day_index, Pixel_index, ]  <- OMI_GasProfile[ipixel,]	
    Grid_ScatterW_all[Col_index, Row_index, Day_index, Pixel_index, ]    <- OMI_ScatterW[ipixel,]	
    Grid_PreLevel_all[Col_index, Row_index, Day_index, Pixel_index, ]    <- OMI_PreLevel[ipixel,]		
  }
}

#---> Do regridding
for(icol in 1: NCOLS_GRID){
  for(irow in 1: NROWS_GRID){
    
    # Get daily averages first
    for(iday in 1: NDAYS){
      if(Grid_N[icol, irow, iday] > Pixel_limit){
        Grid_VCD_d[icol, irow, iday]      <- mean(Grid_VCD_all[icol, irow, iday, ],na.rm=T)
        Grid_SCD_d[icol, irow, iday]      <- mean(Grid_SCD_all[icol, irow, iday, ],na.rm=T)
        Grid_Corr_d[icol, irow, iday]     <- mean(Grid_Corr_all[icol, irow, iday, ],na.rm=T)
        Grid_AMF_d[icol, irow, iday]      <- mean(Grid_AMF_all[icol, irow, iday, ],na.rm=T)
        Grid_AMF_new_d[icol, irow, iday]  <- mean(Grid_AMF_new_all[icol, irow, iday, ],na.rm=T)
        Grid_AMFg_d[icol, irow, iday]     <- mean(Grid_AMFg_all[icol, irow, iday, ],na.rm=T)			
        Grid_Albedo_d[icol, irow, iday]   <- mean(Grid_Albedo_all[icol, irow, iday, ],na.rm=T)			
        Grid_VCD_new_d[icol, irow, iday]  <- mean(Grid_VCD_new_all[icol, irow, iday, ],na.rm=T)
        for(ilayer in 1:NLEVS_GC){
          Grid_GasProfile_d[icol, irow, iday, ilayer] <- mean(Grid_GasProfile_all[icol, irow, iday, , ilayer],na.rm=T)
          Grid_ScatterW_d[icol, irow, iday, ilayer]   <- mean(Grid_ScatterW_all[icol, irow, iday, , ilayer],na.rm=T)
          Grid_PreLevel_d[icol, irow, iday, ilayer]   <- mean(Grid_PreLevel_all[icol, irow, iday, , ilayer],na.rm=T)				
        }
      }
    }
    
    # Now average all obs based on daily averages
    Grid_VCD[icol, irow]      <- mean(Grid_VCD_d[icol, irow, ],na.rm=T)
    Grid_SCD[icol, irow]      <- mean(Grid_SCD_d[icol, irow, ],na.rm=T)
    Grid_Corr[icol, irow]     <- mean(Grid_Corr_d[icol, irow,],na.rm=T)
    Grid_AMF[icol, irow]      <- mean(Grid_AMF_d[icol, irow, ],na.rm=T)
    Grid_AMF_new[icol, irow]  <- mean(Grid_AMF_new_d[icol, irow, ],na.rm=T)
    Grid_AMFg[icol, irow]     <- mean(Grid_AMFg_d[icol, irow, ],na.rm=T)			
    Grid_Albedo[icol, irow]   <- mean(Grid_Albedo_d[icol, irow, ],na.rm=T)
    Grid_VCD_new[icol, irow]  <- mean(Grid_VCD_new_d[icol, irow, ],na.rm=T)
    for(ilayer in 1:NLEVS_GC){
      Grid_GasProfile[icol, irow, ilayer] <- mean(Grid_GasProfile_d[icol, irow, , ilayer],na.rm=T)
      Grid_ScatterW[icol, irow, ilayer]   <- mean(Grid_ScatterW_d[icol, irow, , ilayer],na.rm=T)
      Grid_PreLevel[icol, irow, ilayer]   <- mean(Grid_PreLevel_d[icol, irow, , ilayer],na.rm=T)				
    }
    
  }
}

# ------------------------------------------------------------------------------------------
# Save RData
# ------------------------------------------------------------------------------------------
RData_name3	          <- paste(RData_folder,Campaign_NO,"_",Campaign_name,"_satellite_column.RData",sep="")

save(file=RData_name3, Grid_GasProfile, Grid_ScatterW     , Grid_PreLevel, Plot_Lat_grid, Plot_Lon_grid,
     Grid_VCD_d , Grid_VCD_new_d, Grid_VCD        , Grid_SCD , Grid_VCD_new , Grid_Corr    , 
     Grid_AMF   , Grid_AMFg         , Grid_Albedo, L2_file_used )

write.csv2(L2_file_used, row.names=F, file=paste(RData_folder,Campaign_NO,"_",Campaign_name,"_satellite_list",sep=""))
