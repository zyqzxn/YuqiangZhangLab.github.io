#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                         Computing and Ploting script for validation                     ++
#                         Lei Zhu (leizhu@fas.harvard.edu), 07/20/2020                    ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

# Set Campaign ID
Campaign_ID         <- 1

#---> Load libraies
library(fields); library(rhdf5); library(SDMTools); library(RNetCDF); library(lubridate)

#---> Set working dir
setwd("/data/working/validation/")

#---> Load my tools
source("tools.R")

#---> Output fig files
FigFolder           <- "figs_new/"

#---> RData folder
RData_folder        <- "RData/"

#---> Res
Res                 <- 0.5

#---> Get Campaign information
Campaign_info       <- read.table("Campaigns.dat", header=T)
Campaign_NO         <- as.character(Campaign_info$No[Campaign_ID])
Campaign_name       <- as.character(Campaign_info$Campaign[Campaign_ID])
Campaign_date       <- seq(as.Date(Campaign_info$Date_Start[Campaign_ID]), as.Date(Campaign_info$Date_End[Campaign_ID]), "days")
NDAYS               <- length(Campaign_date)

#---> Get Plot region
Plot_Lon_grid       <- seq(Campaign_info$PlotLon1[Campaign_ID]+0.5*Res,Campaign_info$PlotLon2[Campaign_ID]-0.5*Res,by=Res)
Plot_Lat_grid       <- seq(Campaign_info$PlotLat1[Campaign_ID]+0.5*Res,Campaign_info$PlotLat2[Campaign_ID]-0.5*Res,by=Res)

#---> Get the region of interest
Region_Lon          <- c(Campaign_info$StudyLon1[Campaign_ID],Campaign_info$StudyLon2[Campaign_ID],
                         Campaign_info$StudyLon2[Campaign_ID],Campaign_info$StudyLon1[Campaign_ID])
Region_Lat          <- c(Campaign_info$StudyLat2[Campaign_ID],Campaign_info$StudyLat2[Campaign_ID],
                         Campaign_info$StudyLat1[Campaign_ID],Campaign_info$StudyLat1[Campaign_ID])
Col_left            <- which.min(abs(min(Region_Lon)-Plot_Lon_grid))
Col_right           <- which.min(abs(max(Region_Lon)-Plot_Lon_grid))
Row_low             <- which.min(abs(min(Region_Lat)-Plot_Lat_grid))
Row_up              <- which.min(abs(max(Region_Lat)-Plot_Lat_grid))

#---> Read 1976 US Standard Atmosphere
Standard_Air        <- read.table("1976_US_air.data",header=T)
Standard_Air_H      <- Standard_Air$alt    # km
Standard_Air_P      <- Standard_Air$press/100  # hPa

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Set plot-related variables
#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#                         1       2     3     4       5      6      7      8      9      10      11    12
# Plot size
plot_height_all     <- c(6.0 )
plot_width_all      <- c(4.3 )

# Flight tracks
Flight_min          <- 0
Flight_max          <- 5

# Vertical profiles
Profile_xmax 		    <- 6
Profile_ymax        <- 12

# Satellite columns
Satellite_min       <- 0
Satellite_max       <- c(25)

# New GC columns
NewSatellite_min    <- 0
NewSatellite_max    <- c(25)

# Corrected GC columns
CorrectedGC_min     <- 0
CorrectedGC_max     <- c(25)


#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                              Load ATom-1 and 2 RData                                    ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

RData_name	             <- paste(RData_folder,"C11_ATom-1_profile.RData",sep="")
load(RData_name)
Profile_Obs_mean_P_ATom1 <- Profile_Obs_mean_P
Profile_Obs_mean_T_ATom1 <- Profile_Obs_mean_T
Profile_Obs_mean_ATom1   <- Profile_Obs_mean[,1]
Integrated_column_ATom1  <- sum(Profile_Obs_mean_P_ATom1*100*6.02e23/8.314/Profile_Obs_mean_T_ATom1*1e-6*Profile_Obs_mean_ATom1*1e-9*500*1e2, na.rm=T)

RData_name	             <- paste(RData_folder,"C12_ATom-2_profile.RData",sep="")
load(RData_name)
Profile_Obs_mean_P_ATom2 <- Profile_Obs_mean_P
Profile_Obs_mean_T_ATom2 <- Profile_Obs_mean_T
Profile_Obs_mean_ATom2   <- Profile_Obs_mean[,1]
Integrated_column_ATom2  <- sum(Profile_Obs_mean_P_ATom2*100*6.02e23/8.314/Profile_Obs_mean_T_ATom2*1e-6*Profile_Obs_mean_ATom2*1e-9*500*1e2, na.rm=T)

Integrated_column_ATom   <- (Integrated_column_ATom1+Integrated_column_ATom2)/2

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                     Check P, T, ...                                     ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

#---> Load RData
RData_name	        <- paste(RData_folder,Campaign_NO,"_",Campaign_name,"_profile.RData",sep="")
load(RData_name)

plot(Avg_Obs_MX[,1],Avg_GC_MX*1e-3)
cor(Avg_Obs_MX[,1],Avg_GC_MX*1e-3)

plot(Avg_Obs_P,Avg_GC_P)
cor(Avg_Obs_P,Avg_GC_P)

plot(Avg_GC_Lat,Avg_Obs_Lat)
cor(Avg_GC_Lat,Avg_Obs_Lat)

plot(Avg_Obs_Lon,Avg_GC_Lon)
cor(Avg_Obs_Lon,Avg_GC_Lon)

plot(Avg_Obs_T[which(Avg_Obs_T>0)],Avg_GC_T[which(Avg_Obs_T>0)])
mean( Avg_GC_T[which(Avg_Obs_T>0)] - Avg_Obs_T[which(Avg_Obs_T>0)])
cor(Avg_Obs_T[which(Avg_Obs_T>0)],Avg_GC_T[which(Avg_Obs_T>0)])

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                      Plot 1                                             ++
#                                   Flight track                                          ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

dummy       <- array(-99,dim=c(length(Plot_Lon_grid),length(Plot_Lat_grid)))
v_min       <- Flight_min
v_max       <- Flight_max
plot_height <- plot_height_all[Campaign_ID]
plot_width  <- plot_width_all[Campaign_ID]

plotname	<- paste(FigFolder,Campaign_NO,"_",Campaign_name,"_Flight_tracks",".png",sep="")
png(plotname, width=plot_width, height=plot_height, units="in", res=400)
par(mar=c(2.5,1.8,1.5,1))# Bottom, left, top, right
image.plot(Plot_Lon_grid,Plot_Lat_grid,dummy,zlim=c(v_min,v_max),
           horizontal=T,legend.shrink=1,axis.args = list(cex.axis =1,padj=-1.75,tck=0.2),
           legend.width=1,legend.mar=1,
           legend.args=list(text=expression(paste("HCHO [ppbv]")),padj=0.15,cex=1),          
           xlab='',ylab='',midpoint=T,axes=F,ann=F
)
title(xlab="",cex.lab=1.25,font.lab=2)
axis(1,at=pretty(Plot_Lon_grid),tck=0.015,lwd=1.5,cex.axis=1.75,font=1,padj=-0.5)
axis(3,at=pretty(Plot_Lon_grid),tck=0.015,lwd=1.5,labels=F)
title(ylab="",cex.lab=1.25,font.lab=2)
axis(2,at=pretty(Plot_Lat_grid),tck=0.015,lwd=1.5,cex.axis=1.75,font=1,las=1,hadj=0.5)
axis(4,at=pretty(Plot_Lat_grid),tck=0.015,lwd=1.5,labels=F)
title(main=paste(Campaign_NO,Campaign_name),cex.main=2,font.main=2)
map('state',add=T,lwd=1.25,col="gray40")
box(lwd=2)

#for(i_point in 1:Obs_points){
#  # First plot all in gray
#  points(Obs_Lon[i_point],Obs_Lat[i_point],col="black",cex=0.3,pch=16)
#}

for(i_point in 1:Obs_points){
  # Then plot PBL obs in color
#  if(Obs_H[i_point]<2){
    col_id <- (Obs_MX[i_point,1]-v_min)/(v_max-v_min)*64
    if(col_id > 64){col_id <- 64}
    points(Obs_Lon[i_point],Obs_Lat[i_point],col=tim.colors()[col_id],cex=0.4,pch=16)
#  }
}

# Add polygon
polygon(Region_Lon, Region_Lat, col = NULL, lty = 1, lwd = 2, border = "green")
#text((max(Plot_Lon_grid)-min(Plot_Lon_grid))*0.95+min(Plot_Lon_grid),
#     (max(Plot_Lat_grid)-min(Plot_Lat_grid))*0.95+min(Plot_Lat_grid),Flight_panel[Campaign_ID],cex=Flight_cex[Campaign_ID],font=2)

dev.off()

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                      Plot 2                                             ++
#                                   Vertical profiles                                     ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

xmax 		  <- Profile_xmax
ymax      <- Profile_ymax
plot_y 		<- seq(0.5*(MAX_Height/Ngroups),(MAX_Height-0.5*(MAX_Height/Ngroups)),by=(MAX_Height/Ngroups))

plotname	<- paste(FigFolder,Campaign_NO,"_",Campaign_name,"_profile_height.png",sep="")
png(plotname, width=5, height=8, units="in", res=400)
par(mar=c(4,4,3,3))# Bottom, left, top, right

plot(Profile_GC_mean, plot_y, type="l",xlim=c(0, xmax),ylim=range(c(0,ymax)),axes=F,ann=F,lwd=1,col="red")

axis(1, at=pretty(seq(0, xmax,by=0.5)),lwd=2,tck=0.02,padj=-0.8,cex.axis = 1.25)
axis(2, at=seq(0,ymax,by=1),lwd=2,tck=0.02,hadj=0.4,cex.axis = 1.25,las=1)
mtext(side = 2, text = "Altitude [km]" , line = 3, cex=2   , padj=0.75   )
mtext(side = 1, text = "HCHO [ppb]"   , line = 3, cex=2   , padj=-0.75)
mtext(side = 3, text = paste(Campaign_NO, Campaign_name), line = 3, cex=1.75, padj=1.5 )
#mtext(side = 3, text = "Southern US", line = 3, cex=1.5, padj=3.2 )

# add sd
for(ii in 1:(length(Profile_Obs_mean[,1])-1)){
  y_temp <- c(plot_y[ii], plot_y[ii], plot_y[ii+1], plot_y[ii+1])
  x_temp <- c(Profile_Obs_mean[ii,1]-Profile_Obs_sd[ii],
              Profile_Obs_mean[ii,1]+ Profile_Obs_sd[ii],
              Profile_Obs_mean[ii+1,1]+ Profile_Obs_sd[ii+1],
              Profile_Obs_mean[ii+1,1]-Profile_Obs_sd[ii+1])
  polygon(x_temp, y_temp,col="gray90",border="gray90")
}

lines(Profile_Obs_mean[,1], plot_y, type="l",xlim=c(0, xmax),ylim=range(c(0,MAX_Height)),lwd=3,col="black")
lines(Profile_GC_mean, plot_y, type="l",xlim=c(0, xmax),ylim=range(c(0,MAX_Height)),lwd=3,col="red")

#text(2.25,6000,"Observation",col="black",cex=1.5)
#text(2.25,5500,"GEOS-Chem",col="red",cex=1.5)
box(lwd=2)
dev.off()

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                           Compare GEOS-Chem and obsered columns                         ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

GC_Integrated_column   <- sum(Profile_GC_mean_P*100*6.02e23/8.314/Profile_GC_mean_T*1e-6*Profile_GC_mean*1e-9*500*1e2, na.rm=T)
Obs_Integrated_column  <- sum(Profile_Obs_mean_P*100*6.02e23/8.314/Profile_Obs_mean_T*1e-6*Profile_Obs_mean[,1]*1e-9*500*1e2, na.rm=T)
print( paste(" ==> GEOS-Chem column (1E+15): ", format(round(GC_Integrated_column/1e15, 2))) )
print( paste(" ==> Observed column (1E+15) : ", format(round(Obs_Integrated_column/1e15,2))) )
print( paste(" ==> GEOS-Chem mean bias (%) : ", format(round(GC_Integrated_column/Obs_Integrated_column-1,3)*100,2)) )

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                   Get grids with obs                                    ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

Obs_grid_count <- array(0,dim=c(length(Plot_Lon_grid), length(Plot_Lat_grid)))
for(i_point in 1:Obs_points){
  if( Obs_Lat[i_point]<=max(Region_Lat) && Obs_Lat[i_point]>=min(Region_Lat) && 
      Obs_Lon[i_point]<=max(Region_Lon) && Obs_Lon[i_point]>=min(Region_Lon) ){
    Obs_grids_row <- which.min(abs(Obs_Lat[i_point]-Plot_Lat_grid))[1] 
    Obs_grids_col <- which.min(abs(Obs_Lon[i_point]-Plot_Lon_grid))[1] 
    Obs_grid_count[Obs_grids_col, Obs_grids_row] <- Obs_grid_count[Obs_grids_col, Obs_grids_row] + 1
  }
}

Obs_grid_col <- c()
Obs_grid_row <- c()
for(icol in 1:length(Plot_Lon_grid)){
  for(irow in 1:length(Plot_Lat_grid)){
    if(Obs_grid_count[icol, irow] > 0){
      Obs_grid_col <- c(Obs_grid_col, icol)
      Obs_grid_row <- c(Obs_grid_row, irow)
    }
  }
}

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                      Plot 3                                             ++
#                         OMI profiles and scattering weights                             ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

#---> Load RData
RData_name2	        <- paste(RData_folder,Campaign_NO,"_",Campaign_name,"_satellite_column.RData",sep="")
load(RData_name2)

# ------------------------------------------------------------------------------------------
# Get mean profiles and scattering weights
# ------------------------------------------------------------------------------------------

#---> Get mean a-prior profile, pressure levels, and scattering weights
#     Averaged over the domain during the campigan
OMI_GasProfile_avg             <- array(NA,dim=c(47))
OMI_ScatterW_avg               <- array(NA,dim=c(47))
OMI_PreLevel_avg               <- array(NA,dim=c(47))
OMI_AMFg_avg                   <- c()

for(ilayer in 1:47){
	OMI_GasProfile_avg[ilayer] <- mean(Grid_GasProfile[Col_left:Col_right, Row_low:Row_up, ilayer], na.rm=T)
	OMI_ScatterW_avg[ilayer]   <- mean(Grid_ScatterW[Col_left:Col_right  , Row_low:Row_up, ilayer], na.rm=T)
	OMI_PreLevel_avg[ilayer]   <- mean(Grid_PreLevel[Col_left:Col_right  , Row_low:Row_up, ilayer], na.rm=T)	
}

OMI_AMFg_avg                   <- mean(Grid_AMFg[Col_left:Col_right  , Row_low:Row_up], na.rm=T)

# ------------------------------------------------------------------------------------------
# Convert Pressure to Sigma coordinates
# ------------------------------------------------------------------------------------------

# Compute the pressure at edge
OMI_PreLevel_edge <- array(NA,dim=c(48))
OMI_PreLevel_edge[48]          <- 0
for(ilayer in 1:47){
	OMI_PreLevel_edge[48-ilayer] <- OMI_PreLevel_avg[48-ilayer]*2 - OMI_PreLevel_edge[48-ilayer+1]
}

# Compute sigma, dsigma, and height of each level
OMI_Sigma_center               <- array(NA,dim=c(47))
OMI_dSigma                     <- array(NA,dim=c(47))
OMI_dH                         <- array(NA,dim=c(47))

OMI_Sigma_edge                 <- (OMI_PreLevel_edge-min(OMI_PreLevel_edge))/(max(OMI_PreLevel_edge)-min(OMI_PreLevel_edge))

# Get the height of each level
OMI_H_edge                     <- splint(Standard_Air_P, Standard_Air_H, OMI_PreLevel_edge, df=length(Standard_Air_H))

# Can not higher than 80km
OMI_H_edge[which(OMI_H_edge>80)] <- 80
for(ilayer in 1:47){
	OMI_dSigma[ilayer]           <- OMI_Sigma_edge[ilayer] - OMI_Sigma_edge[ilayer+1]
	OMI_Sigma_center[ilayer]     <- (OMI_Sigma_edge[ilayer] + OMI_Sigma_edge[ilayer+1])*0.5
	OMI_dH[ilayer]               <- OMI_H_edge[ilayer+1] - OMI_H_edge[ilayer]
}

# Check
#plot(Standard_Air_P, Standard_Air_H,type="l")
#points(OMI_PreLevel_edge, OMI_H_edge)

#---> Compute OMI Shape factor
OMI_ShapeFactor_avg              <- OMI_GasProfile_avg/sum(OMI_GasProfile_avg)/OMI_dSigma

#---> Compute Obs Shape factor


#---> Load ATom-1 and 2 obs profiles, use for 

Profile_Obs_mean_ATom            <- (Profile_Obs_mean_ATom1 + Profile_Obs_mean_ATom2)/2 # ppb
Profile_Obs_mean_P_ATom          <- (Profile_Obs_mean_P_ATom1 + Profile_Obs_mean_P_ATom2)/2
Profile_Obs_mean_T_ATom          <- (Profile_Obs_mean_T_ATom1 + Profile_Obs_mean_T_ATom2)/2

for(ilevel in 1:length(Profile_Obs_mean[,1])){
  if( is.na(Profile_Obs_mean[ilevel,1]) && !is.na(Profile_Obs_mean_ATom[ilevel]) ){
    Profile_Obs_mean[ilevel,1] <- Profile_Obs_mean_ATom[ilevel]
    Profile_Obs_mean_P[ilevel] <- Profile_Obs_mean_P_ATom[ilevel]
    Profile_Obs_mean_T[ilevel] <- Profile_Obs_mean_T_ATom[ilevel]
  }
}

Obs_number_desnity               <- Profile_Obs_mean_P*100*6.02e23/8.314/Profile_Obs_mean_T*1e-6*Profile_Obs_mean[,1]*1e-9 # molec. cm-3

#---> Project number density and T to the OMI grids

# Make sure no extrapolation
Obs_number_desnity_OMI_grid      <- array(NA,dim=c(47))
OMI_lev1                         <- min(which( (OMI_PreLevel_avg-max(Profile_Obs_mean_P, na.rm=T))<0 ))
OMI_lev2                         <- max(which( (OMI_PreLevel_avg-min(Profile_Obs_mean_P, na.rm=T))>0 ))
Profile_Obs_mean_P2              <- Profile_Obs_mean_P[which(!is.na(Profile_Obs_mean_P))]
Obs_number_desnity2              <- Obs_number_desnity[which(!is.na(Obs_number_desnity))]

Obs_number_desnity_OMI_grid[OMI_lev1:OMI_lev2] <- splint(Profile_Obs_mean_P2, Obs_number_desnity2, OMI_PreLevel_avg[OMI_lev1:OMI_lev2], df=length(Obs_number_desnity2))
Obs_partial_density_OMI_grid     <- Obs_number_desnity_OMI_grid*OMI_dH*1e5 #m olec. cm-2
# Fill the NA with OMI values
Obs_partial_density_OMI_grid[which(is.na(Obs_partial_density_OMI_grid))] <- OMI_GasProfile_avg[which(is.na(Obs_partial_density_OMI_grid))]
# Compute Obs Shape factor
Obs_ShapeFactor_avg              <- Obs_partial_density_OMI_grid/sum(Obs_partial_density_OMI_grid)/OMI_dSigma

# Compute AMF
AMF_OMI                          <- sum(OMI_ScatterW_avg*OMI_ShapeFactor_avg*OMI_dSigma,na.rm=T)*mean(OMI_AMFg_avg,na.rm=T)
AMF_Obs                          <- sum(OMI_ScatterW_avg*Obs_ShapeFactor_avg*OMI_dSigma,na.rm=T)*mean(OMI_AMFg_avg,na.rm=T)

# ------------------------------------------------------------------------------------------
# Plot AMF
# ------------------------------------------------------------------------------------------

plotname	<- paste(FigFolder,Campaign_NO,"_",Campaign_name,"_AMF.png",sep="")

png(plotname, width=6, height=6, units="in", res=400)
par(mar = c(4.5, 5, 5.5, 5) ) # Leave space for z axis
x_min <- 0
x_max <- 10
plot_pressure <- rev(seq(0,1000,by=50))
plot(OMI_ShapeFactor_avg, OMI_PreLevel_avg,type="l",axes=F,bty="n",xlab="",ylab="",col="blue",xlim=c(x_min,x_max),lwd=2,lty=1,ylim=rev(range(OMI_PreLevel_avg)))
lines(Obs_ShapeFactor_avg, OMI_PreLevel_avg,type="l",bty="n",xlab="",ylab="",col="black",xlim=c(x_min,x_max),lwd=2,lty=1,ylim=rev(range(OMI_PreLevel_avg)))

text(0.6*x_max,150,paste("Observed (AMF=",format(round(AMF_Obs, 2), nsmall = 2), ")",sep=""),col="black",cex=1.25)
text(0.6*x_max,220,paste("OMI (AMF="     ,format(round(AMF_OMI, 2), nsmall = 2), ")",sep=""),col="blue" ,cex=1.25)

axis(side=1, at = pretty(seq(x_min,x_max,by=0.1)),cex.axis=1.25, lwd=2, padj=-0.7, tck=-0.01)

par(new = TRUE)
x_min2 <- 0
x_max2 <- 1.2
plot(OMI_ScatterW_avg, OMI_PreLevel_avg,type="l",axes=FALSE,bty="n",xlab="",ylab="",col="blue",xlim=c(x_min2,x_max2),lwd=2,lty=5,ylim=rev(range(OMI_PreLevel_avg))) 
lines(OMI_ScatterW_avg*OMI_ShapeFactor_avg, OMI_PreLevel_avg,type="l",bty="n",xlab="",ylab="",col="blue",xlim=c(x_min2,x_max2),lwd=2,lty=3,ylim=rev(range(OMI_PreLevel_avg))) 
lines(OMI_ScatterW_avg*Obs_ShapeFactor_avg, OMI_PreLevel_avg,type="l",bty="n",xlab="",ylab="",col="black",xlim=c(x_min2,x_max2),lwd=2,lty=3,ylim=rev(range(OMI_PreLevel_avg))) 

axis(side=2, at = pretty(rev(c(0,1000))),cex.axis=1.25, las=2, hadj=0.7, lwd=2, tck=-0.01)
axis(side=3, at = c(0.0,0.2,0.4,0.6,0.8,1.0,1.2,1.4),cex.axis=1.25, padj=0.7, lwd=2, tck=-0.01)

mtext(expression(paste("Pressure [hPa]")), side=2, padj=-0.5, line=2,cex=1.5)
mtext(expression(paste("S(",sigma,") (solid)")), side=1, line=2, padj=0.2, cex=1.5)
mtext(expression(paste("w(",sigma,") (dashed); ", "S(",sigma,")w(",sigma,") (dotted)" )), side=3, line=2,padj=0.4,cex=1.5)

par(new = TRUE)
plot(-99,-99,type="l",axes=FALSE,bty="n",xlab="",ylab="",col="black",xlim=c(x_min2,x_max2),lwd=4,lty=5,ylim=rev(range(seq(0,1,by=0.1))))  
axis(side=4, pretty(rev(range(seq(0,1,by=0.1)))),cex.axis=1.25, las=2, hadj=0.5, lwd=2, tck=-0.01)
mtext(expression(paste("Sigma coordinate (", sigma, ")")), side=4, line=2, padj=0.4, cex=1.5)
     
box(lwd=3)
dev.off()


#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                      Plot 4                                             ++
#                               Satellite mean columns                                    ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

# Mean column over the domain, averaged during the campigan period

zmin        <- Satellite_min
zmax        <- Satellite_max[Campaign_ID]

plotname	<- paste(FigFolder,Campaign_NO,"_",Campaign_name,"_OMI_column",".png",sep="")
png(plotname, width=plot_width, height=plot_height, units="in", res=400)
par(mar=c(2.5,1.5,1.5,1))# Bottom, left, top, right
image.plot(Plot_Lon_grid,Plot_Lat_grid, Grid_VCD/1e15,zlim=c(zmin,zmax),
           horizontal=T,legend.shrink=1,axis.args = list(cex.axis =1,padj=-1.75,tck=0.2),
           legend.width=1,legend.mar=1,
           legend.args=list(text=expression(paste("HCHO column [",10^15," molecules ",cm^-2,"]",sep="")),padj=0.15,cex=1),           
           xlab='',ylab='',midpoint=T,axes=F,ann=F
)
title(xlab="",cex.lab=1.25,font.lab=2)
axis(1,at=pretty(Plot_Lon_grid),tck=0.015,lwd=1.5,cex.axis=1,font=1,padj=-1.5)
axis(3,at=pretty(Plot_Lon_grid),tck=0.015,lwd=1.5,labels=F)
title(ylab="",cex.lab=1.25,font.lab=2)
axis(2,at=pretty(Plot_Lat_grid),tck=0.015,lwd=1.5,cex.axis=1,font=1,las=1,hadj=0.2)
axis(4,at=pretty(Plot_Lat_grid),tck=0.015,lwd=1.5,labels=F)

title(main=paste(Campaign_NO,Campaign_name,"OMI column"),cex.main=1.1,font.main=2)
map('state',add=T,lwd=1.25,col="gray40")
polygon(Region_Lon, Region_Lat, col = NULL, lty = 1, lwd = 3, border = "green")

for(ip in 1:length(Obs_grid_col)){
  points(Plot_Lon_grid[Obs_grid_col[ip]], Plot_Lat_grid[Obs_grid_row[ip]], pch=1, col="black",lwd=1)
}

box(lwd=2)
dev.off()

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                      Plot 5                                             ++
#                           Updated Satellite mean columns                                ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

# Mean column over the domain, averaged during the campigan period
range(Grid_VCD_new/1e15, na.rm=T)
zmin        <- NewSatellite_min
zmax        <- NewSatellite_max[Campaign_ID]

plotname	<- paste(FigFolder,Campaign_NO,"_",Campaign_name,"_OMI_new_column",".png",sep="")
png(plotname, width=plot_width, height=plot_height, units="in", res=400)
par(mar=c(2.5,1.5,1.5,1))# Bottom, left, top, right
image.plot(Plot_Lon_grid,Plot_Lat_grid, Grid_VCD_new/1e15,zlim=c(zmin,zmax),
           horizontal=T,legend.shrink=1,axis.args = list(cex.axis =1,padj=-1.75,tck=0.2),
           legend.width=1,legend.mar=1,
           legend.args=list(text=expression(paste("HCHO column [",10^15," molecules ",cm^-2,"]",sep="")),padj=0.15,cex=1),           
           xlab='',ylab='',midpoint=T,axes=F,ann=F
)
title(xlab="",cex.lab=1.25,font.lab=2)
axis(1,at=pretty(Plot_Lon_grid),tck=0.015,lwd=1.5,cex.axis=1,font=1,padj=-1.5)
axis(3,at=pretty(Plot_Lon_grid),tck=0.015,lwd=1.5,labels=F)
title(ylab="",cex.lab=1.25,font.lab=2)
axis(2,at=pretty(Plot_Lat_grid),tck=0.015,lwd=1.5,cex.axis=1,font=1,las=1,hadj=0.2)
axis(4,at=pretty(Plot_Lat_grid),tck=0.015,lwd=1.5,labels=F)

title(main=paste(Campaign_NO,Campaign_name,"updated column"),cex.main=1.1,font.main=2)
map('state',add=T,lwd=1.25,col="gray40")
polygon(Region_Lon, Region_Lat, col = NULL, lty = 1, lwd = 3, border = "green")
box(lwd=2)
for(ip in 1:length(Obs_grid_col)){
  points(Plot_Lon_grid[Obs_grid_col[ip]], Plot_Lat_grid[Obs_grid_row[ip]], pch=1, col="black",lwd=1)
}
dev.off()

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                      Plot 5                                             ++
#                                      Albedo                                             ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

# Mean column over the domain, averaged during the campigan period
range(Grid_Albedo, na.rm=T)
zmin        <- 0
zmax        <- 0.1

plotname	<- paste(FigFolder,Campaign_NO,"_",Campaign_name,"_OMI_Albedo",".png",sep="")
png(plotname, width=plot_width, height=plot_height, units="in", res=400)
par(mar=c(2.5,1.5,1.5,1))# Bottom, left, top, right
image.plot(Plot_Lon_grid,Plot_Lat_grid, Grid_Albedo,zlim=c(zmin,zmax),
           horizontal=T,legend.shrink=1,axis.args = list(cex.axis =1,padj=-1.75,tck=0.2),
           legend.width=1,legend.mar=1,
           legend.args=list(text=expression(paste("Surface Albedo [unitless]",sep="")),padj=0.15,cex=1),           
           xlab='',ylab='',midpoint=T,axes=F,ann=F
)
title(xlab="",cex.lab=1.25,font.lab=2)
axis(1,at=pretty(Plot_Lon_grid),tck=0.015,lwd=1.5,cex.axis=1,font=1,padj=-1.5)
axis(3,at=pretty(Plot_Lon_grid),tck=0.015,lwd=1.5,labels=F)
title(ylab="",cex.lab=1.25,font.lab=2)
axis(2,at=pretty(Plot_Lat_grid),tck=0.015,lwd=1.5,cex.axis=1,font=1,las=1,hadj=0.2)
axis(4,at=pretty(Plot_Lat_grid),tck=0.015,lwd=1.5,labels=F)

title(main=paste(Campaign_NO,Campaign_name,"Surface Albedo"),cex.main=1.1,font.main=2)
map('state',add=T,lwd=1.25,col="gray40")
polygon(Region_Lon, Region_Lat, col = NULL, lty = 1, lwd = 3, border = "green")
box(lwd=2)
dev.off()

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                      Plot 6                                             ++
#                        GEOS-Chem mean column, corrected                                 ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

#---> Load RData
RData_name3	        <- paste(RData_folder,Campaign_NO,"_",Campaign_name,"_GC_column.RData",sep="")
load(RData_name3)

zmin        <- CorrectedGC_min
zmax        <- CorrectedGC_max[Campaign_ID]

plotname            <- paste(FigFolder,Campaign_NO,"_",Campaign_name,"_GC_column",".png",sep="")
png(plotname, width=plot_width, height=plot_height, units="in", res=400)
par(mar=c(2.5,1.5,1.5,1))# Bottom, left, top, right
image.plot(Plot_Lon_grid,Plot_Lat_grid, GC_HCHO_OMI_grids$z/1e15*Obs_Integrated_column/GC_Integrated_column,zlim=c(zmin, zmax),
           horizontal=T,legend.shrink=1,axis.args = list(cex.axis =1,padj=-1.75,tck=0.2),
           legend.width=1,legend.mar=1,
           legend.args=list(text=expression(paste("HCHO column [",10^15," molecules ",cm^-2,"]",sep="")),padj=0.15,cex=1),           
           xlab='',ylab='',midpoint=T,axes=F,ann=F
)
title(xlab="",cex.lab=1.25,font.lab=2)
axis(1,at=pretty(Plot_Lon_grid),tck=0.015,lwd=1.5,cex.axis=1,font=1,padj=-1.5)
axis(3,at=pretty(Plot_Lon_grid),tck=0.015,lwd=1.5,labels=F)
title(ylab="",cex.lab=1.25,font.lab=2)
axis(2,at=pretty(Plot_Lat_grid),tck=0.015,lwd=1.5,cex.axis=1,font=1,las=1,hadj=0.2)
axis(4,at=pretty(Plot_Lat_grid),tck=0.015,lwd=1.5,labels=F)

title(main=paste(Campaign_NO,Campaign_name,"corrected GC column"),cex.main=1.1,font.main=2)
map('state',add=T,lwd=1.25,col="gray40")
polygon(Region_Lon, Region_Lat, col = NULL, lty = 1, lwd = 3, border = "green")
box(lwd=2)
for(ip in 1:length(Obs_grid_col)){
  points(Plot_Lon_grid[Obs_grid_col[ip]], Plot_Lat_grid[Obs_grid_row[ip]], pch=1, col="black",lwd=1)
}
dev.off()

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                                      Plot 7                                             ++
#                          Plot time series of columns and T                              ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

# Get daily mean values over the domian of interest

Col_left_GC                               <- which.min(abs(min(Region_Lon)-Lon_grid_GC))
Col_right_GC                              <- which.min(abs(max(Region_Lon)-Lon_grid_GC))
Row_low_GC                                <- which.min(abs(min(Region_Lat)-Lat_grid_GC))
Row_up_GC                                 <- which.min(abs(max(Region_Lat)-Lat_grid_GC))

GC_column_daily_domian_average            <- c()
GC_T_daily_domian_average                 <- c()
Satellite_column_daily_domian_average     <- c()

for(iday in 1: NDAYS){
	# Is this date with obs?
	#if(length(which(Date_with_obs_index==iday))){
		GC_mean_column_temp               <- mean(GC_VCD_1314LT_daily_avg[Col_left_GC:Col_right_GC, Row_low_GC:Row_up_GC, iday], na.rm=T)
		GC_mean_T_temp                    <- mean(GC_T_1314LT_daily_avg[Col_left_GC:Col_right_GC, Row_low_GC:Row_up_GC, iday], na.rm=T)
		Satellite_mean_column_temp        <- mean(Grid_VCD_daily[Col_left:Col_right, Row_low:Row_up, iday], na.rm=T)
	#}else{
	#	GC_mean_column_temp               <- NA
	#	GC_mean_T_temp                    <- NA
	#	Satellite_mean_column_temp        <- NA		
	#}
	GC_column_daily_domian_average        <- c(GC_column_daily_domian_average, GC_mean_column_temp)
	GC_T_daily_domian_average             <- c(GC_T_daily_domian_average, GC_mean_T_temp)	
	Satellite_column_daily_domian_average <- c(Satellite_column_daily_domian_average, Satellite_mean_column_temp)	
}

# # ------------------------------------------------------------------------------------------
# # Plot time series
# # ------------------------------------------------------------------------------------------
# 
# plotname            <- paste(FigFolder,Campaign_NO,"_",Campaign_name,"_timeseries",".png",sep="")
# dates               <- Campaign_date
# ymin                <- 0
# ymax                <- 25
#   
# png(plotname, width=12, height=6, units="in", res=400)
# split.screen(matrix(c(0,0,1,1,0,0.35,0.35,1),ncol=4))
#   
# screen(2)
# par(mar=c(0.1,5.5,2,1)) #bottom, left, top, right
# plot(dates, Satellite_column_daily_domian_average/1e15,ann=F,axes=F, xlab="",ylab="",type="l",lwd=2,col="blue",ylim=c(ymin,ymax))
# lines(dates, GC_column_daily_domian_average/(GC_Integrated_column/Obs_Integrated_column)/1e15,xlab="",ylab="",type="l",lwd=2,col="black",ylim=c(ymin,ymax))
# axis(2, at=pretty(seq(ymin,ymax,by=1)),lwd=2,cex.axis=1.25,las=2)
# title(ylab= expression(paste("HCHO column [",10^15, " molecules ",cm^-2,"]")),cex.lab=1.25,font.main=2)
# mtext(side=3, text="Time series of HCHO columns", cex=2, font=1, padj=-0.2)
# axis.Date(3, at=seq(min(Campaign_date), max(Campaign_date), "weeks"),lwd=2,labels = FALSE,cex.axis=1.25, tcl = 0.6)
# axis.Date(3, at=seq(min(Campaign_date), max(Campaign_date), "days"),labels = FALSE, tcl = 0.3)
# 
# r_GC_T  <- Cal_r(GC_T_daily_domian_average, GC_column_daily_domian_average)  
# r_OMI_T <- Cal_r(GC_T_daily_domian_average, Satellite_column_daily_domian_average)  
# text(Campaign_date[3],ymax*0.95,paste("GEOS-Chem (", as.character(round(r_GC_T,2)),")",sep="") ,col="black", cex=1.3, font=2)  
# text(Campaign_date[3],ymax*0.85,paste("OMI (", as.character(round(r_OMI_T,2)),")",sep="") ,col="blue", cex=1.3, font=2)  
# box(lwd=2)
#   
# screen(1)
# par(mar=c(2.0,5.5,0.1,1)) #bottom, left, top, right
# T_min <- 281
# T_max <- 289
# plot(dates, GC_T_daily_domian_average,ann=F,axes=F, xlab="",ylab="",type="o",pch=16,lty=1,cex=1.5,lwd=2,col="black",ylim=c(T_min,T_max))
# axis(2, at=pretty(seq(T_min,T_max,by=2)),lwd=2,cex.axis=1.25,las=2)
# title(ylab="Midday T [K]",cex.lab=1.25,font.main=2)
# axis.Date(1, at=seq(min(Campaign_date), max(Campaign_date), "weeks"),lwd=2, cex.axis=1.25, tcl = 0.6)
# axis.Date(1, at=seq(min(Campaign_date), max(Campaign_date), "days"),labels = FALSE, tcl = 0.3)
# box(lwd=2)
#   
# close.screen(all.screens = TRUE) 
#   
# dev.off() 

#print("================================================================================")
#print( paste(" ==> Daily GC column and T            , r : ", round(Cal_r(GC_T_daily_domian_average, GC_column_daily_domian_average),2) ) )
#print( paste(" ==> Daily satellite column and T     , r : ", round(Cal_r(GC_T_daily_domian_average, Satellite_column_daily_domian_average),2) ) )
#print( paste(" ==> GC and satellite column (daily)  , r : ", round(Cal_r(GC_column_daily_domian_average, Satellite_column_daily_domian_average),2) ) )
#print( paste(" ==> GC and satellite column (spatial), r : ", round(Cal_r(Campaign_average_Satellite_column_list, Campaign_average_GC_column_list),2) ) )

#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                           Compare satellite and GC mean values                          ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

# Get the mean OMI VCD within the doamin
Satellite_mean_VCD            <- mean(Grid_VCD[Col_left: Col_right, Row_low: Row_up],na.rm=T)
Satellite_mean_AMF            <- mean(Grid_AMF[Col_left: Col_right, Row_low: Row_up],na.rm=T)
Satellite_mean_SCD            <- mean(Grid_SCD[Col_left: Col_right, Row_low: Row_up],na.rm=T)
Satellite_mean_Corr           <- mean(Grid_Corr[Col_left: Col_right, Row_low: Row_up],na.rm=T)
Satellite_mean_VCD1           <- mean((Grid_SCD[Col_left: Col_right, Row_low: Row_up]-
                                       Grid_Corr[Col_left: Col_right, Row_low: Row_up])/
                                       Grid_AMF[Col_left: Col_right, Row_low: Row_up],na.rm=T)
Satellite_mean_VCD2           <- (Satellite_mean_SCD-Satellite_mean_Corr)/Satellite_mean_AMF

Updated_satellite_mean_column <- (Satellite_mean_SCD-Satellite_mean_Corr)/AMF_Obs
GC_mean_column                <- mean(GC_HCHO_OMI_grids$z[Col_left: Col_right, Row_low: Row_up],na.rm=T)
Obs_informed_GC_mean_column   <- GC_mean_column/( GC_Integrated_column/Obs_Integrated_column)

# Get campigan average list
Campaign_average_Satellite_column_list    <- c()
Campaign_average_GC_column_list           <- c()

for(row in Row_low: Row_up){
  for(col in Col_left: Col_right){
    Campaign_average_Satellite_column_list <- c(Campaign_average_Satellite_column_list, Grid_VCD[col,row])
    Campaign_average_GC_column_list        <- c(Campaign_average_GC_column_list, GC_HCHO_OMI_grids$z[col,row])		
  }
}

# Get spatial corraltion between columns and albedo
Region2              <- c(-120,-118,34,39)
Col_left2            <- which.min(abs(Region2[1]-Plot_Lon_grid))
Col_right2           <- which.min(abs(Region2[2]-Plot_Lon_grid))
Row_low2             <- which.min(abs(Region2[3]-Plot_Lat_grid))
Row_up2              <- which.min(abs(Region2[4]-Plot_Lat_grid))

Satellite_SCD    <- c() 
Satellite_Albedo1 <- c()

for(col in Col_left: Col_right){
  for(row in Row_low: Row_up){
    if( !is.na(Grid_SCD[col,row]) && !is.na(Grid_Albedo[col,row]) ){
      Satellite_SCD    <- c(Satellite_SCD, Grid_SCD[col,row])
      Satellite_Albedo1 <- c(Satellite_Albedo1,Grid_Albedo[col,row] )
    }
  }
}

# 
Satellite_VCD    <- c() 
Satellite_Albedo2 <- c()
for(col in Col_left: Col_right){
  for(row in Row_low: Row_up){
    if( !is.na(Grid_VCD[col,row]) && !is.na(Grid_Albedo[col,row]) ){
      Satellite_VCD    <- c(Satellite_VCD, Grid_VCD[col,row])
      Satellite_Albedo2 <- c(Satellite_Albedo2,Grid_Albedo[col,row] )
    }
  }
}

print("================================================================================")
print( paste(" ==> GC mean column (1E+15)               : ", round(GC_mean_column/1e15,2) ) )
print( paste(" ==> Obs-informed GC mean column (1E+15)  : ", round(Obs_informed_GC_mean_column/1e15,2) ) )

print("================================================================================")
print( paste(" ==> Satellite mean AMFg                  : ", round(OMI_AMFg_avg,2 )))
print( paste(" ==> Satellite mean AMF                   : ", round(Satellite_mean_AMF,2) ) )
print( paste(" ==> Mean AMF using satellite profiles    : ", round(AMF_OMI,2) ) )
print( paste(" ==> Mean SCD                             : ", round(Satellite_mean_SCD/1e15,2) ) )
print( paste(" ==> Mean correction                      : ", round(Satellite_mean_Corr/1e15,2) ) )
print( paste(" ==> Satellite mean VCD, averaged (1E+15) : ", round(Satellite_mean_VCD/1e15,2)  ) )
print( paste("     Mean bias (%)                        : ", format(round(Satellite_mean_VCD/Obs_informed_GC_mean_column-1,3)*100,0)) )

print("================================================================================")
print( paste(" ==> Satellite mean VCD, computed1 (1E+15): ", round(Satellite_mean_VCD1/1e15,2)  ) )
print( paste("     Mean bias (%)                        : ", format(round(Satellite_mean_VCD1/Obs_informed_GC_mean_column-1,3)*100,0)) )
print( paste(" ==> Satellite mean VCD, computed2 (1E+15): ", round(Satellite_mean_VCD2/1e15,2)  ) )
print( paste("     Mean bias (%)                        : ", format(round(Satellite_mean_VCD2/Obs_informed_GC_mean_column-1,3)*100,0)) )

print("================================================================================")
print( paste(" ==> Mean AMF using observed profiles     : ", round(AMF_Obs,2) ) )
print( paste(" ==> Updated satellite column (1E+15)     : ", round(Updated_satellite_mean_column/1e15,2) ) )
print( paste("     Mean bias (%)                        : ", format(round(Updated_satellite_mean_column/Obs_informed_GC_mean_column-1,3)*100,0)) )

print("================================================================================")
print( paste(" ==> r SCD and Albedo                     : ", round(cor(Satellite_SCD,Satellite_Albedo1),3 )))
print( paste(" ==> r VCD and Albedo                     : ", round(cor(Satellite_VCD,Satellite_Albedo2),3) ) )


#///////////////////////////////////////////////////////////////////////////////////////////
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#                           Compare satellite and GC mean values                          ++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#///////////////////////////////////////////////////////////////////////////////////////////

# Get the mean OMI VCD within the doamin
Satellite_mean_VCD            <- mean(Grid_VCD[Obs_grid_col, Obs_grid_row],na.rm=T)
Satellite_mean_AMF            <- mean(Grid_AMF[Obs_grid_col, Obs_grid_row],na.rm=T)
Satellite_mean_SCD            <- mean(Grid_SCD[Obs_grid_col, Obs_grid_row],na.rm=T)
Satellite_mean_Corr           <- mean(Grid_Corr[Obs_grid_col, Obs_grid_row],na.rm=T)
Satellite_mean_VCD1           <- mean((Grid_SCD[Obs_grid_col, Obs_grid_row]-
                                       Grid_Corr[Obs_grid_col, Obs_grid_row])/
                                       Grid_AMF[Obs_grid_col, Obs_grid_row],na.rm=T)
Satellite_mean_VCD2           <- (Satellite_mean_SCD-Satellite_mean_Corr)/Satellite_mean_AMF

Updated_satellite_mean_column <- (Satellite_mean_SCD-Satellite_mean_Corr)/AMF_Obs
GC_mean_column                <- mean(GC_HCHO_OMI_grids$z[Obs_grid_col, Obs_grid_row],na.rm=T)
Obs_informed_GC_mean_column   <- GC_mean_column/( GC_Integrated_column/Obs_Integrated_column)


print("================================================================================")
print( paste(" ==> GC mean column (1E+15)               : ", round(GC_mean_column/1e15,2) ) )
print( paste(" ==> Obs-informed GC mean column (1E+15)  : ", round(Obs_informed_GC_mean_column/1e15,2) ) )

print("================================================================================")
print( paste(" ==> Satellite mean AMFg                  : ", round(OMI_AMFg_avg,2 )))
print( paste(" ==> Satellite mean AMF                   : ", round(Satellite_mean_AMF,2) ) )
print( paste(" ==> Mean AMF using satellite profiles    : ", round(AMF_OMI,2) ) )
print( paste(" ==> Mean SCD                             : ", round(Satellite_mean_SCD/1e15,2) ) )
print( paste(" ==> Mean correction                      : ", round(Satellite_mean_Corr/1e15,2) ) )
print( paste(" ==> Satellite mean VCD, averaged (1E+15) : ", round(Satellite_mean_VCD/1e15,2)  ) )
print( paste("     Mean bias (%)                        : ", format(round(Satellite_mean_VCD/Obs_informed_GC_mean_column-1,3)*100,0)) )

print("================================================================================")
print( paste(" ==> Satellite mean VCD, computed1 (1E+15): ", round(Satellite_mean_VCD1/1e15,2)  ) )
print( paste("     Mean bias (%)                        : ", format(round(Satellite_mean_VCD1/Obs_informed_GC_mean_column-1,3)*100,0)) )
print( paste(" ==> Satellite mean VCD, computed2 (1E+15): ", round(Satellite_mean_VCD2/1e15,2)  ) )
print( paste("     Mean bias (%)                        : ", format(round(Satellite_mean_VCD2/Obs_informed_GC_mean_column-1,3)*100,0)) )

print("================================================================================")
print( paste(" ==> Mean AMF using observed profiles     : ", round(AMF_Obs,2) ) )
print( paste(" ==> Updated satellite column (1E+15)     : ", round(Updated_satellite_mean_column/1e15,2) ) )
print( paste("     Mean bias (%)                        : ", format(round(Updated_satellite_mean_column/Obs_informed_GC_mean_column-1,3)*100,0)) )

print("================================================================================")
print( paste(" ==> r SCD and Albedo                     : ", round(cor(Satellite_SCD,Satellite_Albedo1),3 )))
print( paste(" ==> r VCD and Albedo                     : ", round(cor(Satellite_VCD,Satellite_Albedo2),3) ) )
