#************************************************************************
# 								Find common elments
#								    common(v1,v2)
#************************************************************************
common <- function(v1, v2){
  r1 <- rle(sort(v1))
  r2 <- rle(sort(v2))
  vals <- intersect(r1$values, r2$values)
  l1 <- r1$lengths[r1$values %in% vals]
  l2 <- r2$lengths[r2$values %in% vals]
  rep(vals, pmin(l1, l2))
}


#************************************************************************
# Convert integer to character, with 0 heading
#************************************************************************ 
Integer2character	<- function(x){
	temp	<- as.character(x)
	if(x<10){
		temp	<- paste("0",temp,sep="")
	}
	return(temp)
}

#************************************************************************
# Read ICT text file
#************************************************************************
read_ICT      <- function(filename){
  strs        <- readLines(filename)
  header_skip <- as.numeric(strsplit(x=strs[1],split=",")[[1]][1])-1
  dat         <- read.csv(text=strs,skip=header_skip,nrows=length(strs),header=T)
  return(dat)
}

#************************************************************************
# Get seconds since 2000-01-01 00:00
#************************************************************************
get_seconds_2010 <- function(c_date){
  second_temp <- as.integer(unclass(difftime(as.Date(c_date), as.Date("2010-01-01"), units = "days")))*24*3600
  return(second_temp)
}

#************************************************************************
# Get UTC (date and time) based on local time
#************************************************************************

Covert_LT2UTC <- function(LT_date, LT_hour, Lon){
	
	Date       <- as.Date(LT_date)
	Origin_day <- paste(as.character(as.integer(substr(LT_date,1,4))-1),"-12-31",sep="")
	
	GMT_hour   <- LT_hour - floor(Lon/15)
	Julian_day <- yday(Date)
	
	if(GMT_hour > 24){
	  GMT_hour   <- GMT_hour - 24
	  Julian_day <- yday(Date) + 1
	}
	if(GMT_hour < 0){
	  GMT_hour   <- GMT_hour + 24
	  Julian_day <- yday(Date) - 1
	}
	
	UTC_date_time <- c()
    UTC_date_time <- c(UTC_date_time, as.character(as.Date(Julian_day, origin=as.Date(Origin_day))))
    UTC_date_time <- c(UTC_date_time, Integer2character(GMT_hour))
	return(UTC_date_time)
}

#************************************************************************
# Get next day
#************************************************************************

get_next_day <- function(date){
	
	Date       <- as.Date(date)
	Origin_day <- paste(as.character(as.integer(substr(date,1,4))-1),"-12-31",sep="")
	Julian_day <- yday(Date)
	next_day   <- as.character(as.Date(Julian_day+1, origin=as.Date(Origin_day)))
	return(next_day)
}

#************************************************************************
# Get r based on two vectors which can contain NAs
#************************************************************************ 
Cal_r <- function(vector1, vector2){
  common1 <- c()
  common2 <- c()
  if(length(vector1)!=length(vector2)){
    print("Lists are not at the same length!!")
  }else{
    for( i in 1:length(vector1)){
      if(!is.na(vector1[i]) && !is.na(vector2[i])){
        common1 <- c(common1, vector1[i])
        common2 <- c(common2, vector2[i])
      }
    }
  }
  return(cor(common1,common2))
}


#************************************************************************
# Get AMF using GC and satellite profiles, with satellite scattering
# weighting functions
#************************************************************************ 

Cal_GC_AMF <- function( P_GC_pix , HCHO_GC_pix  , AD_GC_pix   , BXH_GC_pix, 
                        P_OMI_pix, Shape_OMI_pix, ScaW_OMI_pix, AMFg_OMI_pix ){
  
  # Get GC pressure at each level (center)
  P_TOP                             <- 1e-4 # Top of the atmosphere
  P_edge_GC_pix                     <- c(P_GC_pix,P_TOP)
  P_center_GC_pix                   <- array(NA,dim=c(NLEVS_GC))
  for(ilevel in 1:NLEVS_GC){
    P_center_GC_pix[ilevel]         <- (P_edge_GC_pix[ilevel] + P_edge_GC_pix[ilevel+1])*0.5
  }
  
  # Get GC HCHO number density
  HCHO_ND_GC_pix                    <- HCHO_GC_pix*1e-9*AD_GC_pix  # molec. cm-3
  
  # Project GC number density from GC grids to OMI grids
  GC_ND_OMI_grid                    <- splint(P_center_GC_pix, HCHO_ND_GC_pix, P_OMI_pix, df=length(HCHO_ND_GC_pix))
  
  # Get GC height vs P
  H_edge_GC_pix                     <- array(NA,dim=c(NLEVS_GC+1)) # km
  for(ilevel in 1:(NLEVS_GC+1)){
    if(ilevel==1){
      H_edge_GC_pix[ilevel]         <- 0
    }else{
      H_edge_GC_pix[ilevel]         <- H_edge_GC_pix[ilevel-1] + BXH_GC_pix[ilevel-1]*1e-3
    }
  }
  
  # Get OMI pressure at edge
  P_edge_OMI_pix                    <- array(NA,dim=c(NLEVS_GC+1))
  P_edge_OMI_pix[NLEVS_GC+1]        <- 0
  for(ilev in 1:NLEVS_GC){
    P_edge_OMI_pix[NLEVS_GC-ilev+1] <- P_OMI_pix[NLEVS_GC-ilev+1]*2 - P_edge_OMI_pix[NLEVS_GC-ilev+2]
  }
  
  # Get OMI height vs P
  H_edge_OMI                        <- splint(P_edge_GC_pix, H_edge_GC_pix, P_edge_OMI_pix, df=length(H_edge_GC_pix))
  # Can not higher than 80km
  H_edge_OMI[which(H_edge_OMI>80)]  <- 80
  
  # Compute sigma, dsigma, and height of each level
  OMI_edge_Sigma                    <- (P_edge_OMI_pix-min(P_edge_OMI_pix))/(max(P_edge_OMI_pix)-min(P_edge_OMI_pix))
  OMI_dSigma                        <- array(NA,dim=c(NLEVS_GC))
  OMI_dH                            <- array(NA,dim=c(NLEVS_GC))
  for(ilev in 1:NLEVS_GC){
    OMI_dSigma[ilev]                <- OMI_edge_Sigma[ilev] - OMI_edge_Sigma[ilev+1]
    OMI_dH[ilev]                    <- H_edge_OMI[ilev+1] - H_edge_OMI[ilev]
  }
  
  # Get shape factor
  GC_partial_column_OMI_grid        <- GC_ND_OMI_grid*OMI_dH*1e5 #m olec. cm-2
  # Compute Obs Shape factor
  GC_ShapeFactor                    <- GC_partial_column_OMI_grid/sum(GC_partial_column_OMI_grid)/OMI_dSigma
  
  # Compute OMI Shape factor
  OMI_ShapeFactor                   <- Shape_OMI_pix/sum(Shape_OMI_pix)/OMI_dSigma
  
  # Compute AMF
  GC_AMF                            <- sum(ScaW_OMI_pix*GC_ShapeFactor*OMI_dSigma,na.rm=T)*AMFg_OMI_pix
  OMI_AMF                           <- sum(ScaW_OMI_pix*OMI_ShapeFactor*OMI_dSigma,na.rm=T)*AMFg_OMI_pix
  
  # Return
  return(c(GC_AMF, OMI_AMF))
}